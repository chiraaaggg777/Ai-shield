import { GoogleGenAI, Type } from "@google/genai";
import { ParkingLocation } from "../../parkingLocations";

// Initialize Gemini
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "" 
});

export interface AIParkingInsight {
  summary: string;
  safetyTips: string[];
  bestTime: string;
  predictedAvailability: string;
  riskAssessment: "LOW" | "MODERATE" | "HIGH";
}

export const getAIInsight = async (location: ParkingLocation): Promise<AIParkingInsight> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this parking location for a user looking for safety and convenience:
      Name: ${location.name}
      Safety Score: ${location.safetyScore}/100
      Traffic Level: ${location.trafficLevel}
      
      Provide a detailed smart insight.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "A creative 1-sentence summary of the location." },
            safetyTips: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "3 specific safety tips for this area."
            },
            bestTime: { type: Type.STRING, description: "Best time to park here for maximum safety." },
            predictedAvailability: { type: Type.STRING, description: "Predicted % of finding a spot now." },
            riskAssessment: { 
              type: Type.STRING, 
              enum: ["LOW", "MODERATE", "HIGH"] 
            }
          },
          required: ["summary", "safetyTips", "bestTime", "predictedAvailability", "riskAssessment"]
        }
      }
    });

    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini AI API Error:", error);
    return {
      summary: "AI systems are currently analyzing this zone.",
      safetyTips: ["Stay alert", "Park in well-lit areas", "Use SmartPark live feed"],
      bestTime: "9:00 AM - 4:00 PM",
      predictedAvailability: "75%",
      riskAssessment: "MODERATE"
    };
  }
};

export const generateAIParkingData = async (count: number = 5): Promise<Partial<ParkingLocation>[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate ${count} random, realistic parking locations for a city (like Bangalore). 
      Include creative names, coordinates (around 12.97, 77.59), and mock data for safety metrics.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              latitude: { type: Type.NUMBER },
              longitude: { type: Type.NUMBER },
              safetyScore: { type: Type.NUMBER },
              trafficLevel: { type: Type.STRING, enum: ["Low Traffic", "Medium Traffic", "High Traffic"] },
              reason: { type: Type.STRING },
              lighting: { type: Type.STRING, enum: ["Excellent", "Good", "Poor"] },
              crowdDensity: { type: Type.STRING, enum: ["Active", "Moderate", "Isolated"] },
              motionActivity: { type: Type.STRING, enum: ["High", "Normal", "Low"] }
            },
            required: ["name", "latitude", "longitude", "safetyScore", "trafficLevel", "reason", "lighting", "crowdDensity", "motionActivity"]
          }
        }
      }
    });

    const text = response.text || "[]";
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Data Generation Error:", error);
    return [];
  }
};

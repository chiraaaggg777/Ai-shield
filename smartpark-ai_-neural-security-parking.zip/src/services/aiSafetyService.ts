import { GoogleGenAI } from "@google/genai";

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface SafetyPrediction {
  score: number;
  trafficLevel: "Low Traffic" | "Medium Traffic" | "High Traffic";
  insight: string;
  recommendation: string;
}

/**
 * Predicts safety for a given location and time using Gemini AI.
 */
export async function predictSafety(
  locationName: string,
  lat: number,
  lng: number,
  time: string
): Promise<SafetyPrediction> {
  try {
    const prompt = `
      You are a Smart Parking Safety Intelligence System. 
      Analyze the safety of parking at "${locationName}" (Coordinates: ${lat}, ${lng}) at ${time}.
      Consider factors like:
      1. Time of day (Night is riskier).
      2. Location type (Market, Metro, Hospital, Residential).
      3. General safety profile of Bangalore areas.
      
      Return ONLY a JSON object with:
      {
        "score": number (0-100),
        "trafficLevel": "Low Traffic" | "Medium Traffic" | "High Traffic",
        "insight": "A brief 1-sentence AI insight about the safety factors",
        "recommendation": "A brief 1-sentence recommendation"
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });
    
    const text = response.text || "";
    return JSON.parse(text) as SafetyPrediction;
  } catch (error) {
    console.error("AI Safety Prediction Error:", error);
    // Fallback logic if AI fails
    const hour = parseInt(time.split(":")[0]) || 12;
    const isNight = hour > 19 || hour < 6;
    return {
      score: isNight ? 65 : 88,
      trafficLevel: isNight ? "Medium Traffic" : "Low Traffic",
      insight: "System operating in offline mode. Safety estimate based on time-of-day heuristics.",
      recommendation: isNight ? "Prefer well-lit gated parking." : "Standard parking precautions apply."
    };
  }
}

/**
 * Calculates distance between two coordinates in km.
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

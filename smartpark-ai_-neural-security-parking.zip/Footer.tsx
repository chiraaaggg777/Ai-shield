import { Shield, Github, Twitter, Linkedin, Mail, ArrowUpRight } from "lucide-react";
import { motion } from "motion/react";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="pt-20 pb-10 border-t border-white/10">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500 rounded-xl">
              <Shield className="w-6 h-6 text-black" />
            </div>
            <h2 className="text-2xl font-display font-black text-white uppercase tracking-tighter">AI-SHIELD</h2>
          </div>
          <p className="text-gray-500 max-w-md font-medium leading-relaxed mb-8">
            The world's most advanced AI-powered animal safety system. 
            Protecting wildlife and drivers through real-time computer vision and predictive analytics.
          </p>
          <div className="flex items-center gap-4">
            {[
              { Icon: Github, href: "https://github.com" },
              { Icon: Twitter, href: "https://twitter.com" },
              { Icon: Linkedin, href: "https://linkedin.com" },
              { Icon: Mail, href: "mailto:support@ai-shield.com" }
            ].map(({ Icon, href }, i) => (
              <a 
                key={i} 
                href={href} 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:text-emerald-400 hover:border-emerald-500/30 transition-all"
              >
                <Icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xs font-display font-black text-white uppercase tracking-widest mb-6">System</h3>
          <ul className="space-y-4">
            {['Neural Engine', 'Predictive Map', 'Data Analytics', 'API Access'].map((item) => (
              <li key={item}>
                <a href="#" className="text-xs font-sans font-bold text-gray-500 hover:text-emerald-400 transition-colors uppercase tracking-widest flex items-center gap-2 group">
                  {item} <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-all" />
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-xs font-display font-black text-white uppercase tracking-widest mb-6">Resources</h3>
          <ul className="space-y-4">
            {['Documentation', 'Safety Reports', 'Community', 'Support'].map((item) => (
              <li key={item}>
                <a href="#" className="text-xs font-sans font-bold text-gray-500 hover:text-emerald-400 transition-colors uppercase tracking-widest flex items-center gap-2 group">
                  {item} <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-all" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-10 border-t border-white/5">
        <p className="text-[10px] font-sans font-bold text-gray-600 uppercase tracking-widest">
          © 2026 AI-SHIELD SAFETY SYSTEMS. ALL RIGHTS RESERVED.
        </p>
        <div className="flex items-center gap-8">
          <a href="#" className="text-[10px] font-sans font-bold text-gray-600 hover:text-white transition-colors uppercase tracking-widest">Privacy Policy</a>
          <a href="#" className="text-[10px] font-sans font-bold text-gray-600 hover:text-white transition-colors uppercase tracking-widest">Terms of Service</a>
          <button 
            onClick={scrollToTop}
            className="text-[10px] font-sans font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-2"
          >
            Back to Top
          </button>
        </div>
      </div>
    </footer>
  );
}

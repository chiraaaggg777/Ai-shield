export interface ParkingLocation {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  safetyScore: number;
  trafficLevel: "Low Traffic" | "Medium Traffic" | "High Traffic";
  reason: string;
  distance?: string;
  lighting: "Excellent" | "Good" | "Poor";
  crowdDensity: "Active" | "Moderate" | "Isolated";
  motionActivity: "High" | "Normal" | "Low";
  timeWarning?: string;
}

const areas = [
  "Majestic", "Railway Station", "Rajajinagar", "Magadi Road", "Kamakshipalya", 
  "Sunkadakatte", "Peenya", "Nagasandra", "Dasarahalli", "Jalahalli", 
  "Kengeri", "RR Nagar", "Vijayanagar", "Nagarbhavi", "Banashankari", 
  "KR Market", "Seshadripuram", "West Bangalore", "Mysore Road", "Chamarajpet",
  "MG Road", "Indiranagar", "Marathahalli", "Whitefield", "Koramangala",
  "HSR Layout", "Jayanagar", "JP Nagar", "Malleswaram", "Hebbal",
  "Electronic City", "BTM Layout", "Bannerghatta Road", "Yelahanka", "Frazer Town", "Demo Mode"
];

const REAL_SLOTS: { [key: string]: string[] } = {
  "Majestic": [
    "Kempegowda Bus Station (Majestic)", "KBS Platform 1", "KBS Platform 2", "KBS Platform 3", "KBS Platform 4",
    "KBS Platform 5", "KBS Platform 6", "KBS Platform 7", "KBS Platform 8", "KBS Platform 9",
    "KBS Platform 10", "Majestic Anand Rao Circle", "Freedom Park", "Race Course Road", "Golf Course",
    "Bangalore Turf Club", "Okalipuram Signal", "SRS Bus Stop", "Majestic Metro Station", "Gubbi Thotadappa Road",
    "St. Martha's Hospital", "Sagar Hospitals Majestic", "Mantri Square Mall (Nearby)"
  ],
  "Railway Station": [
    "City Railway Station", "Platform Road", "Sangolli Rayanna Circle", "Okalipuram", "Sheshadripuram",
    "Railway Main Entry", "Railway Back Entry", "Railway Parcel Office", "Station Road Parking", "Railway Colony Gated",
    "City Railway Station Metro", "Railway Hospital"
  ],
  "Rajajinagar": [
    "Rajajinagar ESI", "Rajajinagar 1st Block", "Rajajinagar 6th Block", "Navrang Theatre", "Dr Rajkumar Road",
    "Rajajinagar Metro", "Navarang Circle", "Pipeline Road", "Kurubarahalli", "Saraswathipuram", "KHB Colony", "WOC Road",
    "Orion Mall", "Manipal Hospital Rajajinagar", "Fortis Hospital Rajajinagar", "Rajajinagar 4th Block Market"
  ],
  "Magadi Road": [
    "Magadi Road Toll Gate", "Magadi Road Police Station", "Prasanna Theatre", "Agrahara Dasarahalli", "Kempapura Agrahara",
    "Hosahalli", "Hosahalli Bus Stop", "Bapujinagar", "Bapujinagar Bus Stop", "New Guddadahalli", "Old Guddadahalli",
    "Tavarekere (Magadi side)", "Kaveripura", "Agrahara Dasarahalli Market",
    "Magadi Road Metro", "Leprosy Hospital", "GT World Mall"
  ],
  "Kamakshipalya": [
    "Kamakshipalya", "Kamakshipalya Bus Stop", "Kamakshipalya Depot", "Kamakshipalya Cross", "Kamakshipalya Police Station",
    "Kamakshipalya Market", "Kamakshipalya Gated", "Kamakshipalya 4th Main", "Kamakshipalya 8th Cross", "Kamakshipalya Depot Road",
    "Kamakshipalya Health Centre", "Sumanahalli Metro (Nearby)", "Unity Hospital (Nearby)"
  ],
  "Sunkadakatte": [
    "Sunkadakatte", "Sunkadakatte Bus Stop", "Sunkadakatte Depot", "Sunkadakatte Cross", "Sunkadakatte Market",
    "Sunkadakatte Gated", "Sunkadakatte 1st Stage", "Sunkadakatte 2nd Stage", "Sunkadakatte Police Station", "Sunkadakatte Cross Road",
    "Sunkadakatte Metro (Green Line Extension)", "Sunkadakatte Hospital", "Janapriya Mall"
  ],
  "Peenya": [
    "Peenya 2nd Stage", "Peenya 3rd Stage", "Peenya Industrial Area", "Peenya Gate", "Peenya Metro Station",
    "Peenya Depot", "Peenya 1st Stage", "Peenya 4th Phase", "Peenya Small Scale Industry", "Peenya Workers Colony",
    "Peenya Industry Metro", "ESIC Hospital Peenya"
  ],
  "Nagasandra": [
    "Nagasandra", "Nagasandra Metro", "Nagasandra Gate", "Nagasandra Public", "Nagasandra Gated",
    "Nagasandra 1st Cross", "Nagasandra 2nd Cross", "Nagasandra Market", "Nagasandra Temple", "Nagasandra School",
    "IKEA Nagasandra", "Nagasandra Metro Parking", "Sapthagiri Hospital"
  ],
  "Dasarahalli": [
    "Dasarahalli", "Dasarahalli Gate", "Dasarahalli Metro", "Dasarahalli Market", "Dasarahalli Bus Stop",
    "Dasarahalli Police Station", "Dasarahalli Gated", "Dasarahalli 1st Main", "Dasarahalli 2nd Main", "Dasarahalli Park",
    "Dasarahalli Metro Station", "Sree Lakshmi Hospital"
  ],
  "Jalahalli": [
    "Jalahalli Cross", "Jalahalli Gate", "Jalahalli Metro", "Jalahalli Depot", "Jalahalli Market",
    "Jalahalli Bus Stop", "Jalahalli Police Station", "Jalahalli Gated", "Jalahalli 1st Main", "Jalahalli 2nd Main",
    "Jalahalli Metro Station", "Air Force Hospital Jalahalli"
  ],
  "Kengeri": [
    "Kengeri Satellite Town", "Kengeri Bus Stand", "Kengeri TTMC", "Kengeri Railway Station", "Kengeri Gollahalli",
    "Kengeri Upanagara", "Kommaghatta", "Kommaghatta Cross", "Mailasandra", "Mailasandra Gate", "Ramasandra", "Ramasandra Cross",
    "Kengeri Metro Station", "BGS Gleneagles Global Hospital", "Kengeri Bus Terminal Metro"
  ],
  "RR Nagar": [
    "RR Nagar Arch", "Rajarajeshwari Nagar Gate", "Ideal Homes", "BEML Layout", "BEML Complex",
    "BEML 5th Stage", "BGS Hospital", "RR Nagar Temple", "RR Nagar Global Village", "RR Nagar 1st Stage",
    "Chikkalasandra (via RR Nagar)", "Uttarahalli Road Junction",
    "RR Nagar Metro Station", "Global City Mall", "Rajarajeshwari Hospital"
  ],
  "Vijayanagar": [
    "Vijayanagar", "Vijayanagar Metro", "Maruthi Mandir", "RPC Layout", "Moodalapalya",
    "Muddayanapalya", "Attiguppe", "Attiguppe Signal", "Vijayanagar BDA Complex", "Vijayanagar Club",
    "Hosahalli Bus Stop", "Hosahalli Metro",
    "Vijayanagar Metro Station", "Bunts Sangha Hospital"
  ],
  "Nagarbhavi": [
    "Nagarbhavi Circle", "Nagarbhavi BDA Complex", "Jnana Bharathi", "Jnana Bharathi Campus", "Bangalore University Gate",
    "Nagarbhavi 1st Stage", "Nagarbhavi 2nd Stage", "Nagarbhavi 12th Block", "Nagarbhavi 80ft Road", "Mallathahalli", "Ullal", "Ullal Cross",
    "Mysore Road Metro (Nearby)", "Unity Hospital Nagarbhavi", "Gopalan Arcade Mall"
  ],
  "Banashankari": [
    "Banashankari TTMC", "Banashankari Bus Stand", "Kathriguppe", "Srinagar Bus Stop", "Chikkalasandra",
    "Subramanyapura Cross", "Vajarahalli", "Thalaghattapura", "Banashankari 1st Stage", "Banashankari 2nd Stage",
    "Kathriguppe (link route)", "Banashankari TTMC (link route)",
    "Banashankari Metro Station", "Banashankari Temple", "Motherhood Hospital"
  ],
  "KR Market": [
    "Town Hall", "KR Market", "Kalasi Palya", "Chickpet", "Avenue Road",
    "South End Circle", "Lalbagh West Gate", "Minerva Circle", "Corporation Circle", "KR Market Basement",
    "Sirsi Circle", "Sirsi Signal",
    "KR Market Metro Station", "Victoria Hospital", "Vani Vilas Hospital"
  ],
  "West Bangalore": [
    "Herohalli Cross", "Byadarahalli", "Byadarahalli Bus Stop", "Anjananagar", "Anjananagar Bus Stop",
    "Gollarahatti", "Gollarahatti Bus Stop", "Hegganahalli", "Hegganahalli Cross", "Andrahalli",
    "Andrahalli Main Road", "Herohalli Gate", "Byadarahalli Gate", "Anjananagar Cross", "Gollarahatti Cross",
    "Hegganahalli Gate", "Andrahalli Gate", "Kadabagere Cross", "Kadabagere", "Machohalli", "Machohalli Gate",
    "Gidadakonenahalli", "Gidadakonenahalli Bus Stop", "Sunkalpalya", "Dubasipalya", "Mariyappanapalya", "Mariyappanapalya Bus Stop",
    "West Bangalore Metro (Proposed)", "Prakriya Hospital"
  ],
  "Mysore Road": [
    "Kumbalgodu", "Kumbalgodu Cross", "Kumbalgodu Industrial Area", "Hejjala", "Hejjala Gate",
    "Bidadi", "Bidadi Bus Stand", "Wonderla Gate", "Ketohalli", "Ramohalli Cross", "Channasandra (Mysore Road)",
    "Pantarapalya", "Nayandahalli Metro", "Nayandahalli",
    "Mysore Road Metro Station", "Nayandahalli Metro Station", "Pantharapalya Metro"
  ],
  "Chamarajpet": [
    "Chamarajpet", "Chamarajpet Police Station", "Rayapuram", "Binny Mill", "Jagajeevanram Nagar",
    "Vinayakanagar", "Chamarajpet 1st Main", "Chamarajpet 2nd Main", "Chamarajpet Market", "Chamarajpet Park",
    "Minto Eye Hospital", "St. Luke's Church", "Krishna Rajendra Market Metro"
  ],
  "Seshadripuram": [
    "Seshadripuram", "Devaiah Park", "Srirampura", "Srirampura Harishchandra Ghat", "Seshadripuram College",
    "Seshadripuram Main Road", "Seshadripuram Police Station", "Seshadripuram Market", "Seshadripuram Gated", "Seshadripuram 1st Cross",
    "Goraguntepalya", "Govt Soap Factory", "Mahalakshmi Layout", "Yeshwanthpur Bus Stand",
    "Seshadripuram Metro Station", "Apollo Hospital Seshadripuram"
  ],
  "MG Road": [
    "MG Road Metro Station", "Brigade Road Junction", "Church Street", "1 Sobha Mall", "Garuda Mall",
    "Cauvery Emporium", "MG Road Boulevard", "Mayo Hall", "St. Philomena's Hospital", "MG Road Gated Parking"
  ],
  "Indiranagar": [
    "Indiranagar Metro Station", "100 Feet Road", "CMH Road", "Indiranagar 12th Main", "Indiranagar 6th Main",
    "Chinmaya Mission Hospital", "Cloudnine Hospital", "Indiranagar Club", "Binnamangala", "Indiranagar BDA Complex"
  ],
  "Marathahalli": [
    "Marathahalli Bridge", "Marathahalli Multiplex", "Innovative Multiplex", "Kalamandir Marathahalli", "Marathahalli Market",
    "Sakra World Hospital", "Marathahalli Metro (Proposed)", "Spice Garden", "Munnekolala", "Marathahalli Outer Ring Road"
  ],
  "Whitefield": [
    "Phoenix Marketcity", "VR Bengaluru", "Inorbit Mall Whitefield", "ITPL Main Gate", "Whitefield Metro Station",
    "Manipal Hospital Whitefield", "Columbia Asia Whitefield", "Hope Farm Circle", "Kadugodi", "Whitefield Railway Station"
  ],
  "Koramangala": [
    "Forum Mall Koramangala", "Koramangala 80ft Road", "Koramangala 4th Block", "Koramangala 5th Block", "Koramangala 7th Block",
    "St. John's Medical College Hospital", "Koramangala BDA Complex", "Koramangala Indoor Stadium", "Sony World Junction", "Koramangala Water Tank"
  ],
  "HSR Layout": [
    "HSR Layout 27th Main", "HSR Layout Sector 1", "HSR Layout Sector 2", "HSR Layout Sector 7", "HSR Layout BDA Complex",
    "Narayana Health HSR", "HSR Layout Police Station", "Agara Lake", "HSR Layout 19th Main", "HSR Layout 14th Main"
  ],
  "Jayanagar": [
    "Jayanagar 4th Block", "Jayanagar Metro Station", "Jayanagar BDA Complex", "Jayanagar 9th Block", "Jayanagar 3rd Block",
    "Sagar Hospitals Jayanagar", "Jayanagar Shopping Complex", "Madhavan Park", "Jayanagar 5th Block", "Jayanagar 7th Block"
  ],
  "JP Nagar": [
    "JP Nagar 24th Main", "JP Nagar 15th Cross", "JP Nagar Metro Station", "JP Nagar 6th Phase", "JP Nagar 1st Phase",
    "Aster RV Hospital", "Vega City Mall", "JP Nagar Mini Forest", "JP Nagar 3rd Phase", "JP Nagar 5th Phase"
  ],
  "Malleswaram": [
    "Malleswaram 8th Cross", "Malleswaram 18th Cross", "Malleswaram Railway Station", "Malleswaram Metro Station", "Sampige Road",
    "Manipal Hospital Malleswaram", "Malleswaram Market", "Kadu Malleshwara Temple", "Malleswaram 15th Cross", "Malleswaram Circle"
  ],
  "Hebbal": [
    "Hebbal Flyover", "Hebbal Lake", "Hebbal Railway Station", "Hebbal Metro (Proposed)", "Manyata Tech Park",
    "Aster CMI Hospital", "Hebbal Kempapura", "Hebbal Police Station", "Hebbal Gated Parking", "Hebbal Bus Stop"
  ],
  "Electronic City": [
    "Electronic City Phase 1", "Electronic City Phase 2", "Electronic City Metro (Proposed)", "Infosys Gate 1", "Wipro Gate",
    "Narayana Health City", "Electronic City Flyover", "Electronic City Toll", "Electronic City Market", "Electronic City Gated"
  ],
  "BTM Layout": [
    "BTM Layout 2nd Stage", "BTM Layout 1st Stage", "BTM Layout Water Tank", "BTM Layout 16th Main", "BTM Layout 7th Main",
    "Gangothri Hospital", "BTM Layout Metro (Proposed)", "BTM Layout Lake", "BTM Layout 29th Main", "BTM Layout 10th Main"
  ],
  "Bannerghatta Road": [
    "Bannerghatta Road Meenakshi Mall", "Bannerghatta Road IIMB", "Bannerghatta Road Gottigere", "Bannerghatta Road Hulimavu", "Bannerghatta Road Bilekahalli",
    "Fortis Hospital Bannerghatta", "Apollo Hospital Bannerghatta", "Bannerghatta Road Metro (Proposed)", "Bannerghatta Road Shoppers Stop", "Bannerghatta Road Vega City"
  ],
  "Yelahanka": [
    "Yelahanka New Town", "Yelahanka Old Town", "Yelahanka Railway Station", "Yelahanka Police Station", "Yelahanka Market",
    "Cytecare Cancer Hospital", "Yelahanka Metro (Proposed)", "Yelahanka Gated Parking", "Yelahanka 4th Phase", "Yelahanka 5th Phase"
  ],
  "Frazer Town": [
    "Frazer Town Mosque Road", "Frazer Town MM Road", "Frazer Town Coles Road", "Frazer Town Promenade Road", "Frazer Town Netaji Road",
    "Santosh Hospital", "Frazer Town Police Station", "Frazer Town Market", "Frazer Town Gated Parking", "Frazer Town 1st Cross"
  ],
  "Demo Mode": [
    "Random AI Spotlight Zone", "Demo Multi-Story Gated", "Test Smart Lot 101"
  ]
};

const areaCoords: { [key: string]: { lat: number, lng: number } } = {
  "Majestic": { lat: 12.9760, lng: 77.5730 },
  "Railway Station": { lat: 12.9780, lng: 77.5690 },
  "Rajajinagar": { lat: 12.9882, lng: 77.5543 },
  "Magadi Road": { lat: 12.9750, lng: 77.5450 },
  "Kamakshipalya": { lat: 12.9800, lng: 77.5300 },
  "Sunkadakatte": { lat: 12.9900, lng: 77.5100 },
  "Peenya": { lat: 13.0329, lng: 77.5273 },
  "Nagasandra": { lat: 13.0480, lng: 77.5000 },
  "Dasarahalli": { lat: 13.0400, lng: 77.5150 },
  "Jalahalli": { lat: 13.0450, lng: 77.5400 },
  "Kengeri": { lat: 12.9170, lng: 77.4830 },
  "RR Nagar": { lat: 12.9230, lng: 77.5180 },
  "Vijayanagar": { lat: 12.9640, lng: 77.5330 },
  "Nagarbhavi": { lat: 12.9510, lng: 77.5050 },
  "Banashankari": { lat: 12.9254, lng: 77.5738 },
  "KR Market": { lat: 12.9650, lng: 77.5750 },
  "Seshadripuram": { lat: 12.9880, lng: 77.5750 },
  "West Bangalore": { lat: 12.9850, lng: 77.4900 },
  "Mysore Road": { lat: 12.8500, lng: 77.4200 },
  "Chamarajpet": { lat: 12.9600, lng: 77.5600 },
  "MG Road": { lat: 12.9733, lng: 77.6117 },
  "Indiranagar": { lat: 12.9784, lng: 77.6408 },
  "Marathahalli": { lat: 12.9569, lng: 77.7011 },
  "Whitefield": { lat: 12.9698, lng: 77.7499 },
  "Koramangala": { lat: 12.9352, lng: 77.6245 },
  "HSR Layout": { lat: 12.9121, lng: 77.6446 },
  "Jayanagar": { lat: 12.9300, lng: 77.5800 },
  "JP Nagar": { lat: 12.9063, lng: 77.5857 },
  "Malleswaram": { lat: 12.9984, lng: 77.5726 },
  "Hebbal": { lat: 13.0354, lng: 77.5988 },
  "Electronic City": { lat: 12.8452, lng: 77.6632 },
  "BTM Layout": { lat: 12.9166, lng: 77.6101 },
  "Bannerghatta Road": { lat: 12.8950, lng: 77.5950 },
  "Yelahanka": { lat: 13.1007, lng: 77.5963 },
  "Frazer Town": { lat: 12.9968, lng: 77.6130 },
  "Demo Mode": { lat: 12.9800, lng: 77.6000 }
};

const generateParkingLocations = (): ParkingLocation[] => {
  const locations: ParkingLocation[] = [];

  areas.forEach((areaName, areaIdx) => {
    const anchor = areaCoords[areaName];
    const slots = REAL_SLOTS[areaName] || [];

    slots.forEach((slotName, i) => {
      const id = `blr-${areaIdx}-${i}`;
      const offsetLat = (Math.random() - 0.5) * 0.005;
      const offsetLng = (Math.random() - 0.5) * 0.005;
      const safetyScore = Math.floor(Math.random() * 40) + 60; // 60-100
      
      let trafficLevel: "Low Traffic" | "Medium Traffic" | "High Traffic" = "Low Traffic";
      if (safetyScore < 70) trafficLevel = "High Traffic";
      else if (safetyScore < 85) trafficLevel = "Medium Traffic";

      const lightingOptions: ("Excellent" | "Good" | "Poor")[] = ["Excellent", "Good", "Poor"];
      const crowdOptions: ("Active" | "Moderate" | "Isolated")[] = ["Active", "Moderate", "Isolated"];
      const motionOptions: ("High" | "Normal" | "Low")[] = ["High", "Normal", "Low"];

      const lighting = lightingOptions[Math.floor(Math.random() * 3)];
      const crowdDensity = crowdOptions[Math.floor(Math.random() * 3)];
      const motionActivity = motionOptions[Math.floor(Math.random() * 3)];

      const reasons = [
        "High visibility, active nightlife, 24/7 security patrol.",
        "Automated entry, CCTV coverage, well-lit surroundings.",
        "Residential area, gated entry, frequent police patrolling.",
        "Commercial hub, high footfall, government-monitored CCTV.",
        "Corporate security presence, well-lit tech park vicinity.",
        "Central location, high security, constant surveillance.",
        "Busy market area, active street life, safe environment.",
        "Planned layout, wide roads, good visibility.",
        "Active commercial street, moderate lighting.",
        "Food hub, active late night, high visibility."
      ];

      locations.push({
        id,
        name: slotName,
        latitude: anchor.lat + offsetLat,
        longitude: anchor.lng + offsetLng,
        safetyScore,
        trafficLevel,
        reason: reasons[Math.floor(Math.random() * reasons.length)],
        lighting,
        crowdDensity,
        motionActivity,
        timeWarning: safetyScore > 85 ? "Safe 24/7" : "Safe until 10 PM"
      });
    });
  });

  return locations;
};

export const parkingLocations: ParkingLocation[] = generateParkingLocations();

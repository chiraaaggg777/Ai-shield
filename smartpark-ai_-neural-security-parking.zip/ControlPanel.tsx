import { Settings, Shield, Activity, Target, Database, Cpu, AlertTriangle, Play, Square } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "./utils";

interface ControlPanelProps {
  isAOIEnabled: boolean;
  setIsAOIEnabled: (val: boolean) => void;
  isDetecting: boolean;
  setIsDetecting: (val: boolean) => void;
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  isHUDMode: boolean;
  setIsHUDMode: (val: boolean) => void;
}

export default function ControlPanel({
  isAOIEnabled,
  setIsAOIEnabled,
  isDetecting,
  setIsDetecting,
  riskLevel,
  isHUDMode,
  setIsHUDMode
}: ControlPanelProps) {
  return (
    <div className="flex flex-col gap-6">
      {/* System Controls */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className={cn(
          "p-6 rounded-3xl transition-all duration-500",
          isHUDMode ? "glass-panel-hud" : "bg-white/5 backdrop-blur-xl border border-white/10 shadow-2xl"
        )}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#00FFA3]/10 rounded-xl border border-[#00FFA3]/30">
            <Settings className="w-5 h-5 text-[#00FFA3]" />
          </div>
          <h2 className="text-sm font-display font-bold text-[#FFFFFF] uppercase tracking-[0.1em]">System Controls</h2>
        </div>

        <div className="space-y-4">
          <button 
            onClick={() => setIsDetecting(!isDetecting)}
            className={cn(
              "w-full py-4 rounded-2xl flex items-center justify-center gap-3 transition-all duration-300 font-display font-bold uppercase tracking-[0.15em] text-[10px]",
              isDetecting 
                ? "bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20" 
                : "bg-[#00FFA3]/10 border border-[#00FFA3]/30 text-[#00FFA3] hover:bg-[#00FFA3]/20 shadow-[0_0_10px_rgba(0,255,163,0.1)]"
            )}
          >
            {isDetecting ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isDetecting ? "Terminate Engine" : "Initialize Engine"}
          </button>

          <div className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-white/5 group hover:border-[#00FFA3]/30 transition-colors">
            <div className="flex items-center gap-3">
              <Settings className="w-4 h-4 text-[#E0E0E0] group-hover:text-[#00FFA3] transition-colors" />
              <span className="label-caps text-[#E0E0E0]">HUD Mode</span>
            </div>
            <button 
              onClick={() => setIsHUDMode(!isHUDMode)}
              className={cn(
                "w-10 h-5 rounded-full relative transition-colors duration-300",
                isHUDMode ? "bg-[#00FFA3]" : "bg-white/10"
              )}
            >
              <div className={cn(
                "absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-300",
                isHUDMode ? "left-6 shadow-[0_0_8px_rgba(255,255,255,0.8)]" : "left-1"
              )} />
            </button>
          </div>
        </div>
      </motion.div>

      {/* System Info */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1 }}
        className={cn(
          "p-6 rounded-3xl transition-all duration-500",
          isHUDMode ? "glass-panel-hud" : "bg-white/5 backdrop-blur-xl border border-white/10 shadow-2xl"
        )}
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#00FFA3]/10 rounded-xl border border-[#00FFA3]/30">
            <Activity className="w-5 h-5 text-[#00FFA3]" />
          </div>
          <h2 className="text-sm font-display font-bold text-[#FFFFFF] uppercase tracking-[0.1em]">System Info</h2>
        </div>

        <div className="space-y-4">
          {[
            { label: "Model", value: "COCO-SSD v2", icon: Cpu },
            { label: "Confidence", value: "85% Min", icon: Target },
            { label: "Classes", value: "90+ Objects", icon: Database },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between p-3 bg-black/20 rounded-xl border border-white/5">
              <div className="flex items-center gap-2">
                <item.icon className="w-3.5 h-3.5 text-[#E0E0E0]" />
                <span className="label-caps text-[#E0E0E0]">{item.label}</span>
              </div>
              <span className="text-[10px] font-display font-semibold text-[#FFFFFF] uppercase tracking-tight">{item.value}</span>
            </div>
          ))}

          <div className={cn(
            "mt-4 p-4 rounded-2xl border flex flex-col gap-2",
            riskLevel === "HIGH" ? "bg-red-500/10 border-red-500/30" :
            riskLevel === "MEDIUM" ? "bg-amber-500/10 border-amber-500/30" :
            "bg-[#00FFA3]/10 border-[#00FFA3]/30"
          )}>
            <div className="flex items-center justify-between">
              <span className="label-caps text-[#E0E0E0]">Risk Assessment</span>
              <AlertTriangle className={cn(
                "w-4 h-4",
                riskLevel === "HIGH" ? "text-red-500" :
                riskLevel === "MEDIUM" ? "text-amber-500" :
                "text-[#00FFA3] drop-shadow-[0_0_5px_rgba(0,255,163,0.5)]"
              )} />
            </div>
            <span className={cn(
              "text-lg font-display font-bold uppercase tracking-tight",
              riskLevel === "HIGH" ? "text-red-400" :
              riskLevel === "MEDIUM" ? "text-amber-400" :
              "text-[#00FFA3] drop-shadow-[0_0_8px_rgba(0,255,163,0.5)]"
            )}>{riskLevel} RISK</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

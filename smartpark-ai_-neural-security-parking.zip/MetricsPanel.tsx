import { Shield, Activity, Target, Database, AlertTriangle, TrendingUp, Clock, MapPin, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "./utils";
import { useState, useEffect } from "react";

interface MetricsPanelProps {
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
}

export default function MetricsPanel({ riskLevel }: MetricsPanelProps) {
  const [confidence, setConfidence] = useState(92.4);
  const [detections, setDetections] = useState(142);
  const [uptime, setUptime] = useState(99.9);
  const [confidenceTrend, setConfidenceTrend] = useState("-0.8%");
  const [detectionsTrend, setDetectionsTrend] = useState("+12%");

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate live fluctuations
      setConfidence(prev => {
        const change = (Math.random() - 0.5) * 0.2;
        const newVal = Math.min(99.9, Math.max(85, prev + change));
        setConfidenceTrend(`${change >= 0 ? '+' : ''}${change.toFixed(1)}%`);
        return newVal;
      });

      setDetections(prev => {
        const change = Math.floor((Math.random() - 0.4) * 3);
        const newVal = Math.max(120, prev + change);
        setDetectionsTrend(`${change >= 0 ? '+' : ''}${Math.abs(change)}%`);
        return newVal;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
      <MetricCard
        title="Risk Level"
        value={riskLevel}
        icon={AlertTriangle}
        color={riskLevel === "HIGH" ? "text-red-500" : riskLevel === "MEDIUM" ? "text-amber-500" : "text-[#00FFA3]"}
        trend={riskLevel === "HIGH" ? "+15.4%" : riskLevel === "MEDIUM" ? "+5.2%" : "+2.4%"}
        trendUp={riskLevel !== "LOW"}
        isLoading={riskLevel === "HIGH"}
      />
      <MetricCard
        title="Avg. Confidence"
        value={`${confidence.toFixed(1)}%`}
        icon={Target}
        color="text-[#00FFA3]"
        trend={confidenceTrend}
        trendUp={parseFloat(confidenceTrend) >= 0}
        isLoading={true}
      />
      <MetricCard
        title="Detections/hr"
        value={detections.toString()}
        icon={Activity}
        color="text-[#00FFA3]"
        trend={detectionsTrend}
        trendUp={parseFloat(detectionsTrend) >= 0}
        isLoading={true}
      />
      <MetricCard
        title="System Uptime"
        value={`${uptime}%`}
        icon={Shield}
        color="text-[#00FFA3]"
        trend="Stable"
        trendUp={true}
        isLoading={false}
      />
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, color, trend, trendUp, isLoading }: any) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl relative overflow-hidden group"
    >
      {/* Scanning Effect Overlay */}
      {isLoading && (
        <motion.div 
          initial={{ top: "-100%" }}
          animate={{ top: "200%" }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          className="absolute left-0 right-0 h-20 bg-gradient-to-b from-transparent via-[#00FFA3]/5 to-transparent pointer-events-none z-0"
        />
      )}

      <div className="absolute top-0 right-0 w-24 h-24 bg-[#00FFA3]/5 blur-2xl -z-10 group-hover:bg-[#00FFA3]/10 transition-colors" />
      
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="p-2 bg-white/5 rounded-xl border border-white/10 group-hover:border-[#00FFA3]/30 transition-colors">
          <Icon className={cn("w-5 h-5", color)} />
        </div>
        <div className={cn(
          "flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest",
          trendUp ? "bg-[#00FFA3]/10 text-[#00FFA3]" : "bg-red-500/10 text-red-400"
        )}>
          <TrendingUp className={cn("w-3 h-3", !trendUp && "rotate-180")} />
          {trend}
        </div>
      </div>

      <h3 className="label-caps mb-1 relative z-10">{title}</h3>
      <div className="flex items-baseline gap-2 relative z-10">
        <p className={cn("text-2xl font-display font-bold uppercase tracking-tight drop-shadow-[0_0_8px_rgba(0,255,163,0.3)]", color)}>
          {value}
        </p>
        {isLoading && (
          <Loader2 className="w-3 h-3 text-[#00FFA3]/40 animate-spin" />
        )}
      </div>
      
      <div className="mt-4 flex items-center gap-2 relative z-10">
        <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            whileInView={{ width: trendUp ? "75%" : "40%" }}
            className={cn("h-full bg-gradient-to-r", trendUp ? "from-[#00FFA3] to-[#00FFB2]" : "from-red-500 to-orange-400")}
          />
        </div>
        <span className="label-caps text-[8px] flex items-center gap-1">
          <span className="w-1 h-1 bg-[#00FFA3] rounded-full animate-pulse" />
          Live
        </span>
      </div>
    </motion.div>
  );
}

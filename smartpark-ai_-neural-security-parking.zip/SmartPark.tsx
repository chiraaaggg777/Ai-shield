import { useState, useMemo, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Shield, 
  MapPin, 
  List, 
  Brain, 
  AlertTriangle, 
  Navigation, 
  Share2, 
  Sun, 
  Moon, 
  Search, 
  Filter,
  ArrowRight,
  Star,
  Zap,
  Info,
  Loader2,
  Locate,
  Database,
  LayoutGrid,
  Activity
} from "lucide-react";
import { cn } from "./utils";
import { parkingLocations, ParkingLocation } from "./parkingLocations";
import { getAIInsight, generateAIParkingData, AIParkingInsight } from "./src/services/geminiService";
import GoogleMapReact from 'google-map-react';
import { predictSafety, calculateDistance, SafetyPrediction } from "./src/services/aiSafetyService";

type SmartParkMode = "AI_SUGGESTIONS" | "LIST" | "MAP";

interface SmartParkProps {
  onBack: () => void;
}

const Marker = ({ trafficLevel, name, score, lat, lng, onNavigate }: { trafficLevel: string, name: string, score: number, lat: number, lng: number, onNavigate: (lat: number, lng: number) => void }) => (
  <div className="relative group -translate-x-1/2 -translate-y-1/2">
    <div className={cn(
      "w-8 h-8 rounded-full border-2 flex items-center justify-center shadow-lg cursor-pointer transition-all hover:scale-125",
      trafficLevel === "Low Traffic" ? "bg-emerald-500/20 border-emerald-500" :
      trafficLevel === "Medium Traffic" ? "bg-amber-500/20 border-amber-500" :
      "bg-red-500/20 border-red-500"
    )}>
      <MapPin className={cn(
        "w-4 h-4",
        trafficLevel === "Low Traffic" ? "text-emerald-500" :
        trafficLevel === "Medium Traffic" ? "text-amber-500" :
        "text-red-500"
      )} />
    </div>
    
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto z-50">
      <div className="bg-black/90 backdrop-blur-xl border border-white/10 p-4 rounded-xl shadow-2xl min-w-[180px]">
        <p className="text-xs font-bold text-white mb-2">{name}</p>
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] text-gray-400 uppercase tracking-widest">Safety Score</span>
          <span className={cn(
            "text-[10px] font-bold",
            score > 80 ? "text-emerald-400" : score > 50 ? "text-amber-400" : "text-red-400"
          )}>{score}</span>
        </div>
        <button 
          onClick={() => onNavigate(lat, lng)}
          className="w-full py-2 bg-[#00FFA3] text-black text-[10px] font-black uppercase tracking-widest rounded-lg hover:scale-105 transition-all"
        >
          Navigate
        </button>
      </div>
    </div>
  </div>
);

const UserMarker = ({ lat, lng }: { lat: number, lng: number }) => (
  <div className="relative -translate-x-1/2 -translate-y-1/2">
    <div className="w-6 h-6 bg-blue-500 rounded-full border-4 border-white shadow-xl animate-pulse" />
    <div className="absolute inset-0 bg-blue-500 rounded-full animate-ping opacity-20" />
  </div>
);

export default function SmartPark({ onBack }: SmartParkProps) {
  const [mode, setMode] = useState<SmartParkMode>("AI_SUGGESTIONS");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSafeOnly, setFilterSafeOnly] = useState(false);
  const [sortBy, setSortBy] = useState<"safety" | "distance">("safety");
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showSimulatedMap, setShowSimulatedMap] = useState(false);
  const [aiLocations, setAiLocations] = useState<ParkingLocation[]>([]);
  const [isGeneratingAIData, setIsGeneratingAIData] = useState(false);
  const [selectedAIInsight, setSelectedAIInsight] = useState<AIParkingInsight | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Real-time ML & Location State
  const [userLocation, setUserLocation] = useState<{ lat: number, lng: number } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [aiPrediction, setAiPrediction] = useState<SafetyPrediction | null>(null);
  const [nearbyLocations, setNearbyLocations] = useState<ParkingLocation[]>([]);

  // Initialize Geolocation
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          // Default to Bangalore center if denied
          setUserLocation({ lat: 12.9716, lng: 77.5946 });
        }
      );
    }
  }, []);

  // AI Prediction Engine
  const runAiAnalysis = useCallback(async () => {
    if (!userLocation) return;
    
    setIsScanning(true);
    try {
      // Find the nearest known parking spot to the user
      const sortedByDistance = [...parkingLocations].sort((a, b) => {
        const distA = calculateDistance(userLocation?.lat || 12.9716, userLocation?.lng || 77.5946, a.latitude, a.longitude);
        const distB = calculateDistance(userLocation?.lat || 12.9716, userLocation?.lng || 77.5946, b.latitude, b.longitude);
        return distA - distB;
      });

      const nearest = sortedByDistance[0];
      const time = new Date().toLocaleTimeString();
      
      const prediction = await predictSafety(nearest.name, userLocation?.lat || 12.9716, userLocation?.lng || 77.5946, time);
      setAiPrediction(prediction);
      
      // Update nearby locations
      const updatedNearby = sortedByDistance.slice(0, 10).map(loc => ({
        ...loc
      }));
      setNearbyLocations(updatedNearby);
    } catch (error) {
      console.error("AI Analysis failed:", error);
    } finally {
      setIsScanning(false);
    }
  }, [userLocation]);

  useEffect(() => {
    if (userLocation && mode === "AI_SUGGESTIONS") {
      runAiAnalysis();
    }
  }, [userLocation, mode, runAiAnalysis]);

  const filteredLocations = useMemo(() => {
    const baseList = nearbyLocations.length > 0 ? nearbyLocations : parkingLocations;
    let result = baseList.filter(loc => 
      loc.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (filterSafeOnly) {
      result = result.filter(loc => loc.trafficLevel === "Low Traffic");
    }

    return result.sort((a, b) => {
      return b.safetyScore - a.safetyScore;
    });
  }, [searchQuery, filterSafeOnly, sortBy, nearbyLocations]);

  const bestOption = useMemo(() => {
    const baseList = nearbyLocations.length > 0 ? nearbyLocations : parkingLocations;
    return [...baseList].sort((a, b) => b.safetyScore - a.safetyScore)[0];
  }, [nearbyLocations]);

  const handleShareLocation = () => {
    alert("📍 Live location link copied to clipboard. Share it with your trusted contacts.");
  };

  const handleNavigate = async (lat: number, lng: number) => {
    // Find matching location for AI analysis
    const location = [...parkingLocations, ...aiLocations].find(l => l.latitude === lat && l.longitude === lng);
    
    if (location) {
      setIsAnalyzing(true);
      const insight = await getAIInsight(location);
      setSelectedAIInsight(insight);
      setIsAnalyzing(false);
    }

    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
  };

  const handleGenerateAIData = async () => {
    setIsGeneratingAIData(true);
    const newData = await generateAIParkingData(8);
    
    // Convert to full ParkingLocation objects
    const fullData: ParkingLocation[] = newData.map(d => ({
      id: `ai-${Math.random().toString(36).substr(2, 9)}`,
      name: `[AI] ${d.name}`,
      latitude: d.latitude || 12.97,
      longitude: d.longitude || 77.59,
      trafficLevel: (d.trafficLevel as any) || "Low Traffic",
      safetyScore: d.safetyScore || 85,
      reason: d.reason || "AI identified low-risk zone with active surveillance.",
      lighting: (d.lighting as any) || "Good",
      crowdDensity: (d.crowdDensity as any) || "Moderate",
      motionActivity: (d.motionActivity as any) || "Normal",
      slots: []
    }));

    setAiLocations(prev => [...prev, ...fullData]);
    setIsGeneratingAIData(false);
    setMode("AI_SUGGESTIONS");
  };

  return (
    <div className={cn(
      "min-h-screen pb-20 transition-colors duration-500",
      isDarkMode ? "bg-black text-white" : "bg-gray-50 text-gray-900"
    )}>
      {/* Smart Park Header */}
      <div className="max-w-7xl mx-auto px-6 pt-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className={cn(
                "p-3 border rounded-2xl transition-all",
                isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-gray-200 hover:bg-gray-50 shadow-sm"
              )}
            >
              <Shield className="w-5 h-5 text-[#00FFA3]" />
            </button>
            <div>
              <h2 className={cn(
                "text-3xl font-display font-black uppercase tracking-tighter leading-none mb-1",
                isDarkMode ? "text-white" : "text-black"
              )}>Smart Park</h2>
              <p className="text-[10px] font-sans font-bold text-gray-500 uppercase tracking-widest">Safe Parking Intelligence System</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={cn(
                "p-3 rounded-2xl border transition-all flex items-center gap-2",
                isDarkMode 
                  ? "bg-indigo-500/20 border-indigo-500/50 text-indigo-400" 
                  : "bg-indigo-50 border-indigo-200 text-indigo-600 shadow-sm"
              )}
            >
              {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              <span className="text-[10px] font-bold uppercase tracking-widest">{isDarkMode ? "Dark Mode" : "Light Mode"}</span>
            </button>

            <button 
              onClick={handleGenerateAIData}
              disabled={isGeneratingAIData}
              className={cn(
                "p-3 rounded-2xl border transition-all flex items-center gap-2",
                isDarkMode ? "bg-white/5 border-white/10 text-white" : "bg-white border-gray-200 text-black shadow-sm"
              )}
            >
              {isGeneratingAIData ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4 text-[#00FFA3]" />}
              <span className="text-[10px] font-bold uppercase tracking-widest">{isGeneratingAIData ? "Generating..." : "Gen AI Data"}</span>
            </button>
          </div>
        </div>

        {/* Mode Toggle */}
        <div className="flex justify-center mb-12">
          <div className={cn(
            "p-1.5 border rounded-2xl flex items-center gap-1 backdrop-blur-xl",
            isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-lg"
          )}>
            {[
              { id: "AI_SUGGESTIONS", label: "AI Suggestions", icon: Brain },
              { id: "LIST", label: "List View", icon: List },
              { id: "MAP", label: "Map View", icon: MapPin }
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id as SmartParkMode)}
                className={cn(
                  "px-6 py-3 rounded-xl flex items-center gap-2 transition-all",
                  mode === m.id 
                    ? "bg-[#00FFA3] text-black shadow-[0_0_20px_rgba(0,255,163,0.3)]" 
                    : isDarkMode ? "text-gray-400 hover:text-white hover:bg-white/5" : "text-gray-500 hover:text-black hover:bg-gray-100"
                )}
              >
                <m.icon className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-widest">{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <AnimatePresence mode="wait">
          {mode === "AI_SUGGESTIONS" && (
            <motion.div
              key="suggestions"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {isAnalyzing && (
                <div className="py-12 flex flex-col items-center justify-center gap-4">
                  <Loader2 className="w-12 h-12 text-[#00FFA3] animate-spin" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-[#00FFA3]">AI Engine Analyzing Sector...</p>
                </div>
              )}

              {selectedAIInsight && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-8 bg-gradient-to-br from-[#00FFA3]/20 to-blue-500/10 border border-[#00FFA3]/30 rounded-[2.5rem] relative overflow-hidden mb-12"
                >
                  <button 
                    onClick={() => setSelectedAIInsight(null)}
                    className="absolute top-6 right-6 p-2 bg-black/40 hover:bg-black/60 rounded-full transition-colors text-white z-20"
                  >
                    <ArrowRight className="w-4 h-4 rotate-45" />
                  </button>
                  
                  <div className="relative z-10">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-black rounded-2xl border border-[#00FFA3]/20">
                        <Brain className="w-8 h-8 text-[#00FFA3]" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-display font-black uppercase tracking-tighter text-white">Gemini Pro AI Analysis</h3>
                        <p className="text-[10px] text-gray-400 uppercase tracking-widest font-black">Dynamic Risk Assessment Report</p>
                      </div>
                    </div>
                    
                    <p className="text-xl font-medium text-white mb-8 border-l-2 border-[#00FFA3] pl-6 italic">
                      "{selectedAIInsight.summary}"
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="p-5 bg-black/40 rounded-2xl border border-white/5">
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-2">Safety Protocols</p>
                        <ul className="space-y-2">
                          {selectedAIInsight.safetyTips.map((tip, i) => (
                            <li key={i} className="text-[10px] text-gray-300 flex items-start gap-2">
                              <Shield className="w-3 h-3 text-[#00FFA3] shrink-0" /> {tip}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="p-5 bg-black/40 rounded-2xl border border-white/5">
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-2">Window of Optimization</p>
                        <p className="text-lg font-black text-white">{selectedAIInsight.bestTime}</p>
                        <p className="text-[9px] text-[#00FFA3] uppercase tracking-widest mt-1">Recommended timeframe</p>
                      </div>
                      <div className="p-5 bg-black/40 rounded-2xl border border-white/5">
                        <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-2">Probabilistic Availability</p>
                        <p className="text-lg font-black text-white">{selectedAIInsight.predictedAvailability}</p>
                        <div className={cn(
                          "px-2 py-0.5 rounded text-[8px] font-black uppercase inline-block mt-2",
                          selectedAIInsight.riskAssessment === "LOW" ? "bg-emerald-500/20 text-emerald-400" :
                          selectedAIInsight.riskAssessment === "MODERATE" ? "bg-amber-500/20 text-amber-400" :
                          "bg-red-500/20 text-red-400"
                        )}>
                          Risk: {selectedAIInsight.riskAssessment}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {isScanning ? (
                <div className={cn(
                  "p-20 border rounded-[2rem] flex flex-col items-center justify-center text-center tech-grid",
                  isDarkMode ? "bg-black/40 border-white/5" : "bg-white border-gray-100"
                )}>
                  <Loader2 className="w-12 h-12 text-[#00FFA3] animate-spin mb-6" />
                  <h3 className="text-2xl font-display font-black uppercase tracking-tighter mb-2">AI Engine Scanning...</h3>
                  <p className="text-gray-500 font-mono text-xs uppercase tracking-widest">Analyzing real-time location data & safety patterns</p>
                </div>
              ) : bestOption ? (
                <>
                  {/* Best Option Highlight */}
                  <div className="relative group">
                    <div className="absolute -inset-1 bg-gradient-to-r from-[#00FFA3] to-emerald-500 rounded-[2rem] blur opacity-20 group-hover:opacity-40 transition duration-1000 group-hover:duration-200" />
                    <div className={cn(
                      "relative p-8 border rounded-[2rem] overflow-hidden backdrop-blur-2xl transition-colors duration-500 tech-grid",
                      isDarkMode ? "bg-black/60 border-[#00FFA3]/30" : "bg-white/80 border-[#00FFA3]/50 shadow-xl"
                    )}>
                      <div className="absolute top-0 right-0 p-6 flex items-center gap-4">
                        <div className="flex flex-col items-end">
                          <span className="text-[8px] font-mono text-gray-500 uppercase tracking-[0.2em]">ML Status</span>
                          <span className="text-[10px] font-mono text-[#00FFA3] uppercase animate-pulse">Predicting</span>
                        </div>
                        <div className="px-4 py-2 bg-[#00FFA3] text-black rounded-xl font-black text-[10px] uppercase tracking-widest shadow-[0_0_20px_rgba(0,255,163,0.4)]">
                          AI Recommended
                        </div>
                      </div>

                      <div className="flex flex-col md:flex-row gap-8 items-start">
                        <div className="p-4 bg-[#00FFA3]/10 rounded-3xl border border-[#00FFA3]/20 tech-border">
                          <Brain className="w-12 h-12 text-[#00FFA3]" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Locate className="w-3 h-3 text-emerald-400" />
                            <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest">Near Your Current Location</span>
                          </div>
                          <h3 className={cn(
                            "text-4xl font-display font-black uppercase tracking-tighter mb-2",
                            isDarkMode ? "text-white" : "text-black"
                          )}>{bestOption.name}</h3>
                          <div className="flex flex-wrap items-center gap-4 mb-6">
                            <div className={cn(
                              "flex items-center gap-2 px-3 py-1.5 rounded-lg border",
                              isDarkMode ? "bg-white/5 border-white/10" : "bg-gray-100 border-gray-200"
                            )}>
                              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                              <span className={cn(
                                "text-[10px] font-mono font-bold uppercase tracking-widest",
                                isDarkMode ? "text-white" : "text-gray-700"
                              )}>Safety Score: {aiPrediction?.score || bestOption.safetyScore}</span>
                            </div>
                          </div>
                          <p className={cn(
                            "font-medium mb-8 max-w-2xl leading-relaxed",
                            isDarkMode ? "text-gray-400" : "text-gray-600"
                          )}>
                            <span className="text-[#00FFA3] font-mono font-bold uppercase tracking-widest text-[10px] block mb-2">AI Safety Prediction:</span>
                            {aiPrediction?.insight || bestOption.reason}
                          </p>
                          <div className="flex items-center gap-4">
                            <button 
                              onClick={() => handleNavigate(bestOption.latitude, bestOption.longitude)}
                              className="px-8 py-4 bg-[#00FFA3] text-black font-black uppercase tracking-widest rounded-2xl flex items-center gap-3 hover:scale-105 transition-all"
                            >
                              Navigate Now <ArrowRight className="w-5 h-5" />
                            </button>
                            <button 
                              onClick={handleShareLocation}
                              className={cn(
                                "p-4 border rounded-2xl transition-all",
                                isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-gray-200 hover:bg-gray-50 shadow-sm"
                              )}
                            >
                              <Share2 className="w-5 h-5 text-gray-400" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Other Suggestions */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[...aiLocations, ...nearbyLocations].slice(1, 7).map((loc) => (
                      <SuggestionCard 
                        key={loc.id} 
                        location={loc} 
                        isDarkMode={isDarkMode} 
                        onNavigate={handleNavigate}
                      />
                    ))}
                  </div>
                </>
              ) : (
                <div className={cn(
                  "p-20 border rounded-[2rem] flex flex-col items-center justify-center text-center tech-grid",
                  isDarkMode ? "bg-black/40 border-white/5" : "bg-white border-gray-100"
                )}>
                  <Loader2 className="w-12 h-12 text-gray-600 animate-spin mb-6" />
                  <h3 className="text-2xl font-display font-black uppercase tracking-tighter mb-2">No Suggestions Found</h3>
                  <p className="text-gray-500 font-mono text-xs uppercase tracking-widest">Wait while we load parking data or try a different filter</p>
                </div>
              )}
            </motion.div>
          )}

          {mode === "LIST" && (
            <motion.div
              key="list"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {/* Filters & Search */}
              <div className="flex flex-col md:flex-row gap-4 mb-8">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input 
                    type="text"
                    placeholder="Search parking areas..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={cn(
                      "w-full pl-12 pr-4 py-4 border rounded-2xl focus:outline-none focus:border-[#00FFA3]/50 transition-all font-medium",
                      isDarkMode ? "bg-white/5 border-white/10 text-white placeholder:text-gray-600" : "bg-white border-gray-200 text-black placeholder:text-gray-400 shadow-sm"
                    )}
                  />
                </div>
                <div className={cn(
                  "flex items-center gap-2 p-1.5 border rounded-2xl",
                  isDarkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200 shadow-sm"
                )}>
                  <div className="px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-[#00FFA3]/10 text-[#00FFA3] border border-[#00FFA3]/20">
                    Sorted by Safety
                  </div>
                </div>
                <button 
                  onClick={() => setFilterSafeOnly(!filterSafeOnly)}
                  className={cn(
                    "px-6 py-4 rounded-2xl border transition-all flex items-center gap-2",
                    filterSafeOnly 
                      ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-400" 
                      : isDarkMode ? "bg-white/5 border-white/10 text-gray-400 hover:bg-white/10" : "bg-white border-gray-200 text-gray-500 hover:bg-gray-50 shadow-sm"
                  )}
                >
                  <Filter className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Safe Only</span>
                </button>
              </div>

              <div className="space-y-4">
                {filteredLocations.map((loc) => (
                  <div 
                    key={loc.id}
                    className={cn(
                      "p-6 border rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all group",
                      isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-gray-200 hover:bg-gray-50 shadow-sm"
                    )}
                  >
                    <div className="flex items-center gap-6">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center border",
                        loc.trafficLevel === "Low Traffic" ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500" :
                        loc.trafficLevel === "Medium Traffic" ? "bg-amber-500/10 border-amber-500/30 text-amber-500" :
                        "bg-red-500/10 border-red-500/30 text-red-500"
                      )}>
                        <MapPin className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className={cn(
                          "text-xl font-display font-black uppercase tracking-tighter mb-1",
                          isDarkMode ? "text-white" : "text-black"
                        )}>{loc.name}</h4>
                        <div className="flex items-center gap-3">
                          <span className={cn(
                            "text-[10px] font-bold uppercase tracking-widest",
                            loc.trafficLevel === "Low Traffic" ? "text-emerald-400" :
                            loc.trafficLevel === "Medium Traffic" ? "text-amber-400" :
                            "text-red-400"
                          )}>{loc.trafficLevel}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-[10px] font-sans font-bold text-gray-500 uppercase tracking-widest mb-1">Safety Score</p>
                        <p className={cn(
                          "text-2xl font-data font-bold",
                          loc.safetyScore > 80 ? "text-emerald-400" : loc.safetyScore > 50 ? "text-amber-400" : "text-red-400"
                        )}>{loc.safetyScore}</p>
                      </div>
                      <button 
                        onClick={() => handleNavigate(loc.latitude, loc.longitude)}
                        className={cn(
                          "p-4 border rounded-2xl transition-all",
                          isDarkMode ? "bg-white/5 border-white/10 group-hover:bg-[#00FFA3] group-hover:text-black" : "bg-white border-gray-200 group-hover:bg-[#00FFA3] group-hover:text-black shadow-sm"
                        )}
                      >
                        <Navigation className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {mode === "MAP" && (
            <motion.div
              key="map-v3-hyper"
              initial={{ opacity: 0, y: 20, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.98 }}
              className={cn(
                "h-[700px] w-full rounded-[3rem] overflow-hidden border relative flex flex-col items-center justify-center transition-all duration-1000 group",
                isDarkMode 
                  ? "border-white/10 bg-[#050505] shadow-[0_30px_100px_rgba(0,0,0,0.8)]" 
                  : "border-gray-200 bg-white shadow-[0_20px_60px_rgba(0,0,0,0.08)]"
              )}
            >
              {/* Ultra-Modern Map Stage */}
              {import.meta.env.VITE_GOOGLE_MAPS_API_KEY && import.meta.env.VITE_GOOGLE_MAPS_API_KEY.startsWith("AIza") && !showSimulatedMap ? (
                <div className="w-full h-full relative group/stage">
                  <div className="absolute inset-0 z-[1] pointer-events-none transition-opacity duration-1000 group-hover/stage:opacity-40">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />
                  </div>
                  
                  <GoogleMapReact
                    bootstrapURLKeys={{ 
                      key: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
                      libraries: ['places', 'geometry'] 
                    }}
                    defaultCenter={userLocation || { lat: 12.9716, lng: 77.5946 }}
                    center={(userLocation && typeof userLocation.lat === 'number') ? { lat: userLocation.lat, lng: userLocation.lng } : { lat: 12.9716, lng: 77.5946 }}
                    defaultZoom={14}
                    options={{
                      styles: isDarkMode ? mapDarkStyles : mapLightStyles,
                      disableDefaultUI: true,
                      gestureHandling: 'greedy',
                      clickableIcons: false
                    }}
                  >
                    {userLocation && (
                      <UserMarker
                        lat={userLocation.lat}
                        lng={userLocation.lng}
                      />
                    )}
                    {parkingLocations.map((loc) => (
                      <Marker
                        key={loc.id}
                        lat={loc.latitude}
                        lng={loc.longitude}
                        trafficLevel={loc.trafficLevel}
                        name={loc.name}
                        score={loc.safetyScore}
                        onNavigate={handleNavigate}
                      />
                    ))}
                  </GoogleMapReact>
                  
                  {/* Premium HUD Overlays */}
                  <div className="absolute top-8 left-8 right-8 flex justify-between items-start pointer-events-none z-20">
                     <div className="flex flex-col gap-2">
                        <div className="px-5 py-2.5 bg-black/90 backdrop-blur-2xl border border-white/10 rounded-2xl flex items-center gap-3 pointer-events-auto shadow-2xl">
                           <div className="w-2.5 h-2.5 bg-[#00FFA3] rounded-full animate-ping" />
                           <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Operational Stream Live</span>
                        </div>
                        <div className="px-4 py-2 bg-white/5 backdrop-blur-md border border-white/5 rounded-xl flex items-center gap-4 text-[8px] font-mono text-gray-400 uppercase tracking-widest">
                           <span>LAT: {userLocation?.lat.toFixed(4) || "0.0000"}</span>
                           <div className="w-1 h-1 bg-white/20 rounded-full" />
                           <span>LNG: {userLocation?.lng.toFixed(4) || "0.0000"}</span>
                        </div>
                     </div>
                     
                     <div className="px-5 py-3 bg-black/90 backdrop-blur-2xl border border-white/10 rounded-2xl pointer-events-auto flex items-center gap-6 shadow-2xl">
                        <div className="flex items-center gap-2">
                           <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
                           <span className="text-[9px] font-black text-gray-400 uppercase">Clear</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]" />
                           <span className="text-[9px] font-black text-gray-400 uppercase">Medium</span>
                        </div>
                        <div className="flex items-center gap-2">
                           <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                           <span className="text-[9px] font-black text-gray-400 uppercase">Heavy</span>
                        </div>
                     </div>
                  </div>

                  <div className="absolute bottom-10 left-10 pointer-events-auto">
                    <button 
                      onClick={() => setShowSimulatedMap(true)}
                      className="px-6 py-3 bg-[#00FFA3] text-black rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-[0_15px_40px_rgba(0,255,163,0.3)] hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
                    >
                      <Zap className="w-4 h-4" /> Switch to Simulation
                    </button>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full relative flex items-center justify-center p-12">
                  {showSimulatedMap ? (
                    <SimulatedMap 
                      locations={parkingLocations} 
                      onNavigate={handleNavigate}
                      isDarkMode={isDarkMode}
                      onExit={() => setShowSimulatedMap(false)}
                    />
                  ) : (
                    <div className="text-center max-w-2xl relative z-10">
                      <motion.div 
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="w-24 h-24 bg-red-500/10 border border-red-500/20 rounded-[2rem] flex items-center justify-center mx-auto mb-10 shadow-[0_0_60px_rgba(239,68,68,0.1)]"
                      >
                        <AlertTriangle className="w-12 h-12 text-red-500" />
                      </motion.div>
                      
                      <h3 className={cn(
                        "text-5xl font-display font-black uppercase tracking-tighter mb-6",
                        isDarkMode ? "text-white" : "text-black"
                      )}>Satellite Link <span className="text-red-500">Offline</span></h3>
                      
                      <p className={cn(
                        "text-lg font-medium leading-relaxed mb-12 opacity-60 max-w-lg mx-auto",
                        isDarkMode ? "text-gray-400" : "text-gray-600"
                      )}>
                        Google Maps API key detected. If you see an error, ensure "Maps JavaScript API" is enabled in your Google Cloud Console and that the key has no domain restrictions.
                      </p>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button 
                          onClick={() => setShowSimulatedMap(true)}
                          className="py-5 bg-[#00FFA3] text-black rounded-3xl text-[11px] font-black uppercase tracking-[0.2em] hover:shadow-[0_20px_50px_rgba(0,255,163,0.4)] transition-all flex items-center justify-center gap-3"
                        >
                          <Zap className="w-5 h-5" /> Launch Simulation
                        </button>
                        <button 
                          onClick={() => setMode("LIST")}
                          className={cn(
                            "py-5 border rounded-3xl text-[11px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3",
                            isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10 text-white" : "bg-gray-50 border-gray-200 hover:bg-gray-100 text-black"
                          )}
                        >
                          <List className="w-5 h-5 opacity-40" /> Smart Grid List
                        </button>
                      </div>

                      <div className="mt-16 flex items-center justify-center gap-8 opacity-30">
                         <div className="flex flex-col items-center gap-2">
                           <Database className="w-5 h-5" />
                           <span className="text-[8px] font-mono uppercase tracking-widest">PostgreSQL Indexed</span>
                         </div>
                         <div className="flex flex-col items-center gap-2">
                           <LayoutGrid className="w-5 h-5" />
                           <span className="text-[8px] font-mono uppercase tracking-widest">342 Nodes Analyzed</span>
                         </div>
                      </div>
                    </div>
                  )}
                  
                  {!showSimulatedMap && (
                    <div className="absolute inset-0 pointer-events-none">
                       <div className="absolute inset-0 [background-image:radial-gradient(ellipse_at_center,_transparent_0%,_black_80%)] z-10" />
                       <div className="absolute inset-0 tech-grid opacity-20" />
                       <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#00FFA3]/5 blur-[150px] rounded-full animate-pulse" />
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

        </AnimatePresence>
      </div>

    </div>
  );
}

function SuggestionCard({ location, isDarkMode, onNavigate }: { location: ParkingLocation, isDarkMode: boolean, onNavigate: (lat: number, lng: number) => void }) {
  return (
    <div className={cn(
      "p-6 border rounded-3xl transition-all group relative overflow-hidden",
      isDarkMode ? "bg-white/5 border-white/10 hover:bg-white/10" : "bg-white border-gray-200 hover:bg-gray-50 shadow-sm"
    )}>
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00FFA3]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      
      <div className="flex items-center justify-between mb-6">
        <div className={cn(
          "p-3 rounded-xl border tech-border",
          location.trafficLevel === "Low Traffic" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" :
          location.trafficLevel === "Medium Traffic" ? "bg-amber-500/10 border-amber-500/20 text-amber-500" :
          "bg-red-500/10 border-red-500/20 text-red-500"
        )}>
          <MapPin className="w-5 h-5" />
        </div>
        <div className="text-right">
          <p className="text-[8px] font-mono font-bold text-gray-500 uppercase tracking-widest mb-1">Safety Score</p>
          <p className={cn(
            "text-xl font-mono font-bold",
            location.safetyScore > 80 ? "text-emerald-400" : location.safetyScore > 50 ? "text-amber-400" : "text-red-400"
          )}>{location.safetyScore}</p>
        </div>
      </div>

      <h4 className={cn(
        "text-xl font-display font-black uppercase tracking-tighter mb-2",
        isDarkMode ? "text-white" : "text-black"
      )}>{location.name}</h4>
      <div className="flex items-center gap-3 mb-4">
        <span className={cn(
          "text-[10px] font-mono font-bold uppercase tracking-widest",
          location.trafficLevel === "Low Traffic" ? "text-emerald-400" :
          location.trafficLevel === "Medium Traffic" ? "text-amber-400" :
          "text-red-400"
        )}>{location.trafficLevel}</span>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Lighting</span>
          <span className={cn(
            "text-[10px] font-mono font-bold uppercase tracking-widest",
            isDarkMode ? "text-white" : "text-gray-700"
          )}>{location.lighting}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Crowd</span>
          <span className={cn(
            "text-[10px] font-mono font-bold uppercase tracking-widest",
            isDarkMode ? "text-white" : "text-gray-700"
          )}>{location.crowdDensity}</span>
        </div>
      </div>

      <div className={cn(
        "p-3 rounded-xl border mb-6 tech-grid",
        isDarkMode ? "bg-black/40 border-white/5" : "bg-gray-50 border-gray-100"
      )}>
        <div className="flex items-start gap-2">
          <Info className="w-3 h-3 text-[#00FFA3] mt-0.5" />
          <p className={cn(
            "text-[10px] font-mono leading-relaxed italic",
            isDarkMode ? "text-gray-400" : "text-gray-600"
          )}>{location.reason}</p>
        </div>
      </div>

      <button 
        onClick={() => onNavigate(location.latitude, location.longitude)}
        className={cn(
          "w-full py-3 border rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
          isDarkMode ? "bg-white/5 border-white/10 text-white hover:bg-[#00FFA3] hover:text-black" : "bg-white border-gray-200 text-gray-700 hover:bg-[#00FFA3] hover:text-black shadow-sm"
        )}
      >
        Navigate
      </button>
    </div>
  );
}

function SimulatedMap({ locations, onNavigate, isDarkMode, onExit }: { 
  locations: ParkingLocation[], 
  onNavigate: (lat: number, lng: number) => void, 
  isDarkMode: boolean,
  onExit: () => void 
}) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"GRID" | "ANALYTIC">("GRID");

  return (
    <div className="absolute inset-0 z-10 bg-black tech-grid overflow-hidden flex flex-col">
      {/* Simulation Header */}
      <div className="p-6 border-b border-white/10 bg-black/40 backdrop-blur-xl flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-[#00FFA3]/10 rounded-xl border border-[#00FFA3]/30">
            <Database className="w-5 h-5 text-[#00FFA3]" />
          </div>
          <div>
            <h4 className="text-[10px] font-black text-[#00FFA3] uppercase tracking-[0.3em] mb-1">Neural Simulation Engine v2.0</h4>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">Database Sync: Active</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">Mock Stream: 12.4 GB/s</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setViewMode(viewMode === "GRID" ? "ANALYTIC" : "GRID")}
            className="p-2 border border-white/10 rounded-xl hover:bg-white/5 text-gray-400"
          >
            {viewMode === "GRID" ? <Activity className="w-4 h-4" /> : <LayoutGrid className="w-4 h-4" />}
          </button>
          <button 
            onClick={onExit}
            className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-white hover:bg-white/10"
          >
            Exit Simulation
          </button>
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden flex">
        {/* Left Side: Visualizer */}
        <div className="flex-1 p-8 overflow-y-auto custom-scrollbar relative">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {locations.slice(0, 50).map((loc, i) => (
              <motion.div
                key={loc.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.01 }}
                onMouseEnter={() => setActiveId(loc.id)}
                className={cn(
                  "p-4 border rounded-2xl transition-all cursor-crosshair group",
                  activeId === loc.id ? "bg-white/10 border-[#00FFA3]/50 scale-105" : "bg-black/40 border-white/5 hover:border-white/20"
                )}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center mb-3",
                  loc.trafficLevel === "Low Traffic" ? "bg-emerald-500/20 text-emerald-400" :
                  loc.trafficLevel === "Medium Traffic" ? "bg-amber-500/20 text-amber-400" :
                  "bg-red-500/20 text-red-400"
                )}>
                  <MapPin className="w-4 h-4" />
                </div>
                <h5 className="text-[9px] font-black text-white uppercase tracking-tighter truncate mb-1">{loc.name}</h5>
                <div className="flex items-center justify-between">
                  <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">{loc.trafficLevel.split(' ')[0]}</span>
                  <span className="text-[8px] font-mono text-[#00FFA3]">{loc.safetyScore}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Perspective Grid Background */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03] tech-grid rotate-3 scale-125" />
        </div>

        {/* Right Side: Data Panel */}
        <div className="w-80 border-l border-white/10 bg-black/40 backdrop-blur-2xl p-6 hidden lg:flex flex-col gap-6">
          <div className="space-y-4">
            <h6 className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em]">Active Data Node</h6>
            {activeId ? (
              <div className="space-y-6">
                {locations.find(l => l.id === activeId) && (
                  <>
                    <div>
                      <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter">{locations.find(l => l.id === activeId)?.name}</h3>
                      <p className="text-[9px] font-mono text-[#00FFA3] uppercase tracking-widest mt-1">Status: Optimized for Simulation</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 border border-white/10 rounded-xl bg-white/5">
                        <p className="text-[8px] font-mono text-gray-500 uppercase tracking-widest mb-1">Safety</p>
                        <p className="text-lg font-mono text-white font-black">{locations.find(l => l.id === activeId)?.safetyScore}%</p>
                      </div>
                      <div className="p-3 border border-white/10 rounded-xl bg-white/5">
                        <p className="text-[8px] font-mono text-gray-500 uppercase tracking-widest mb-1">Traffic</p>
                        <p className={cn(
                          "text-lg font-mono font-black",
                          locations.find(l => l.id === activeId)?.trafficLevel === "Low Traffic" ? "text-emerald-400" : "text-amber-400"
                        )}>{locations.find(l => l.id === activeId)?.trafficLevel.split(' ')[0]}</p>
                      </div>
                    </div>

                    <div className="p-4 border border-[#00FFA3]/20 bg-[#00FFA3]/5 rounded-xl">
                      <p className="text-[9px] font-mono text-[#00FFA3] leading-relaxed italic">
                        "Neural analysis indicates a {locations.find(l => l.id === activeId)?.safetyScore}% reliability match during current simulation window."
                      </p>
                    </div>

                    <button 
                      onClick={() => {
                        const loc = locations.find(l => l.id === activeId);
                        if (loc) onNavigate(loc.latitude, loc.longitude);
                      }}
                      className="w-full py-4 bg-white/10 hover:bg-[#00FFA3] hover:text-black border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                    >
                      <Share2 className="w-3 h-3" /> Simulate Route
                    </button>
                  </>
                )}
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center opacity-30">
                <Brain className="w-12 h-12 mb-4 animate-pulse" />
                <p className="text-[9px] font-mono uppercase tracking-[0.2em]">Select Node to Inspect</p>
              </div>
            )}
          </div>
          
          <div className="mt-auto pt-6 border-t border-white/10">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[8px] font-mono text-gray-500 uppercase tracking-widest">Sim Latency</span>
              <span className="text-[8px] font-mono text-[#00FFA3]">0.2ms</span>
            </div>
            <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
              <motion.div 
                animate={{ width: ["20%", "80%", "45%", "90%", "30%"] }}
                transition={{ duration: 5, repeat: Infinity }}
                className="h-full bg-[#00FFA3] shadow-[0_0_10px_rgba(0,255,163,1)]" 
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const mapDarkStyles = [
  { "elementType": "geometry", "stylers": [{ "color": "#212121" }] },
  { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] },
  { "elementType": "labels.text.fill", "stylers": [{ "color": "#757575" }] },
  { "elementType": "labels.text.stroke", "stylers": [{ "color": "#212121" }] },
  { "style": "feature:administrative", "elementType": "geometry", "stylers": [{ "color": "#757575" }] },
  { "style": "feature:water", "elementType": "geometry", "stylers": [{ "color": "#000000" }] },
  { "style": "feature:road", "elementType": "geometry.fill", "stylers": [{ "color": "#2c2c2c" }] }
];

const mapLightStyles = [
  { "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }] },
  { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] },
  { "elementType": "labels.text.fill", "stylers": [{ "color": "#616161" }] },
  { "elementType": "labels.text.stroke", "stylers": [{ "color": "#f5f5f5" }] },
  { "style": "feature:administrative", "elementType": "geometry", "stylers": [{ "color": "#bdbdbd" }] },
  { "style": "feature:water", "elementType": "geometry", "stylers": [{ "color": "#c9c9c9" }] },
  { "style": "feature:road", "elementType": "geometry.fill", "stylers": [{ "color": "#ffffff" }] }
];

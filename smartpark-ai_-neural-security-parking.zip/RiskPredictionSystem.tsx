import { Brain, Database, LineChart, AlertTriangle, ShieldCheck, Zap, ArrowRight, ShieldAlert } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "./utils";

interface RiskPredictionSystemProps {
  predictiveRisk: "LOW" | "MEDIUM" | "HIGH";
  weather: string;
  time: string;
  traffic: string;
  onViewAnalysis?: () => void;
}

export default function RiskPredictionSystem({
  predictiveRisk,
  weather,
  time,
  traffic,
  onViewAnalysis,
}: RiskPredictionSystemProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-20">
      {/* High-Risk Zones Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="lg:col-span-2 p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl relative overflow-hidden group"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 blur-3xl -z-10" />
        
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 rounded-xl border border-emerald-500/30">
              <ShieldAlert className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-2xl font-display font-black text-white uppercase tracking-tighter leading-none mb-1">High-Risk Zones</h2>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">AI-Predicted Collision Hotspots</p>
            </div>
          </div>
          <div className={cn(
            "px-4 py-2 rounded-xl border flex items-center gap-2",
            predictiveRisk === "HIGH" ? "bg-red-500/10 border-red-500/30 text-red-400" :
            predictiveRisk === "MEDIUM" ? "bg-amber-500/10 border-amber-500/30 text-amber-400" :
            "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
          )}>
            <div className={cn(
              "w-2 h-2 rounded-full animate-pulse",
              predictiveRisk === "HIGH" ? "bg-red-500" :
              predictiveRisk === "MEDIUM" ? "bg-amber-500" :
              "bg-emerald-500"
            )} />
            <span className="text-xs font-display font-black uppercase tracking-widest">Current Risk: {predictiveRisk}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="p-4 bg-black/40 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-colors group/item">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-sans font-bold text-white uppercase tracking-widest">Forest Crossing A-12</span>
                <span className="text-[10px] font-display font-bold text-red-400 bg-red-500/10 px-2 py-0.5 rounded uppercase tracking-widest">High Risk</span>
              </div>
              <p className="text-xs text-gray-500 font-medium leading-relaxed">Frequent deer movement detected during {time.toLowerCase()} hours in {weather.toLowerCase()} conditions.</p>
            </div>
            <div className="p-4 bg-black/40 rounded-2xl border border-white/5 hover:border-emerald-500/30 transition-colors group/item">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-sans font-bold text-white uppercase tracking-widest">Highway 401 Sector 4</span>
                <span className="text-[10px] font-display font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded uppercase tracking-widest">Medium Risk</span>
              </div>
              <p className="text-xs text-gray-500 font-medium leading-relaxed">Visibility reduced due to {weather.toLowerCase()} weather. Traffic is currently {traffic.toLowerCase()}.</p>
            </div>
          </div>

          <div className="p-6 bg-emerald-500/5 rounded-3xl border border-emerald-500/10 flex flex-col justify-center text-center">
            <Brain className="w-12 h-12 text-emerald-400 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-display font-black text-white uppercase tracking-tighter mb-2">Predictive Safety System</h3>
            <p className="text-xs text-gray-400 font-medium leading-relaxed mb-6">
              Our AI analyzes patterns from past incidents, real-time weather, and traffic density to predict potential collision zones before you reach them.
            </p>
            <button 
              onClick={onViewAnalysis}
              className="w-full py-3 bg-emerald-500 text-black font-sans font-black uppercase tracking-widest text-xs rounded-xl hover:bg-emerald-400 transition-all flex items-center justify-center gap-2"
            >
              View Detailed Analysis <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* AI Prediction Logic Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl relative overflow-hidden"
      >
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-emerald-500/20 rounded-xl border border-emerald-500/30">
            <Brain className="w-6 h-6 text-emerald-400" />
          </div>
          <h2 className="text-xl font-display font-black text-white uppercase tracking-tighter leading-none">AI Logic</h2>
        </div>

        <div className="space-y-6">
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-emerald-500/10 rounded-xl border border-emerald-500/20 flex items-center justify-center shrink-0">
              <Database className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white uppercase tracking-widest mb-1">Historical Data</h4>
              <p className="text-xs text-gray-500 font-medium leading-relaxed">Processing 50,000+ past collision records to identify seasonal animal migration patterns.</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-emerald-500/10 rounded-xl border border-emerald-500/20 flex items-center justify-center shrink-0">
              <LineChart className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white uppercase tracking-widest mb-1">Trend Analysis</h4>
              <p className="text-xs text-gray-500 font-medium leading-relaxed">Real-time correlation between {weather.toLowerCase()} weather and animal road-crossing frequency.</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-emerald-500/10 rounded-xl border border-emerald-500/20 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white uppercase tracking-widest mb-1">Edge Inference</h4>
              <p className="text-xs text-gray-500 font-medium leading-relaxed">Low-latency prediction updates based on current {traffic.toLowerCase()} traffic density.</p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5">
          <div className="flex items-center justify-between p-4 bg-black/40 rounded-2xl border border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-[10px] font-sans font-bold text-gray-400 uppercase tracking-widest">Prediction Engine</span>
            </div>
            <span className="text-[10px] font-data text-emerald-400 font-bold">STABLE</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

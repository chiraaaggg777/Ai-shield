import { Shield, User, ShieldCheck, ShieldAlert } from "lucide-react";
import { motion } from "motion/react";
import { useAuth } from "./App";
import { signInWithGoogle, logout } from "./firebase";
import { cn } from "./utils";

export default function Header({ currentView, setCurrentView }: { currentView: string, setCurrentView: (view: any) => void }) {
  const { user, loading, isAdmin } = useAuth();

  return (
    <header className="w-full py-6 px-6 border-b border-white/10 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-12">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            onClick={() => setCurrentView("DASHBOARD")}
            className="flex items-center gap-3 group cursor-pointer"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-[#00FFA3] blur-xl opacity-20 group-hover:opacity-40 transition-all duration-500 rounded-full" />
              <div className="relative flex items-center justify-center">
                <div className="absolute inset-0 border border-[#00FFA3]/20 rounded-xl rotate-45 group-hover:rotate-90 transition-transform duration-700" />
                <div className="absolute inset-0 border border-[#00FFA3]/10 rounded-xl -rotate-45 group-hover:-rotate-0 transition-transform duration-700" />
                <div className="relative p-3 bg-black border border-[#00FFA3]/30 rounded-xl shadow-[0_0_25px_rgba(0,255,163,0.2)] group-hover:shadow-[0_0_35px_rgba(0,255,163,0.4)] transition-all">
                  <ShieldCheck className="w-6 h-6 text-[#00FFA3]" strokeWidth={2} />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-[#00FFA3] rounded-full animate-pulse shadow-[0_0_8px_#00FFA3]" />
                </div>
              </div>
            </div>
            <div>
              <h1 className="text-2xl heading-expanded text-[#FFFFFF] mb-1">AI-SHIELD</h1>
              <div className="flex items-center gap-2">
                <span className="label-caps text-[#00FFA3] bg-[#00FFA3]/10 px-1.5 py-0.5 rounded drop-shadow-[0_0_5px_rgba(0,255,163,0.3)]">V1.0</span>
                <div className="w-1 h-1 bg-white/20 rounded-full" />
                <span className="label-caps text-[#E0E0E0]">Auth: {loading ? "..." : user ? "Authorized" : "Guest"}</span>
              </div>
            </div>
          </motion.div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => setCurrentView("DASHBOARD")}
              className={cn(
                "text-[10px] font-black uppercase tracking-[0.2em] transition-all relative group",
                currentView === "DASHBOARD" ? "text-[#00FFA3]" : "text-gray-500 hover:text-white"
              )}
            >
              AI Shield
              {currentView === "DASHBOARD" && (
                <motion.div layoutId="nav-underline" className="absolute -bottom-2 left-0 right-0 h-0.5 bg-[#00FFA3] shadow-[0_0_10px_#00FFA3]" />
              )}
            </button>
            <button 
              onClick={() => setCurrentView("SMART_PARK")}
              className={cn(
                "text-[10px] font-black uppercase tracking-[0.2em] transition-all relative group",
                currentView === "SMART_PARK" ? "text-[#00FFA3]" : "text-gray-500 hover:text-white"
              )}
            >
              Smart Park
              {currentView === "SMART_PARK" && (
                <motion.div layoutId="nav-underline" className="absolute -bottom-2 left-0 right-0 h-0.5 bg-[#00FFA3] shadow-[0_0_10px_#00FFA3]" />
              )}
            </button>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3 pl-3">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-white leading-none mb-1">{user.displayName}</p>
                  <p className="text-[10px] font-medium text-emerald-400 uppercase tracking-widest">{isAdmin ? 'System Admin' : 'Operator'}</p>
                </div>
                <button 
                  onClick={() => {
                    logout().catch(err => console.error("Logout failed", err));
                  }}
                  className="w-10 h-10 rounded-xl border border-white/10 overflow-hidden hover:border-emerald-500/50 transition-all"
                >
                  <img src={user.photoURL || ""} alt="Avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </button>
              </div>
            ) : (
              <button 
                onClick={async () => {
                  try {
                    await signInWithGoogle();
                  } catch (err: any) {
                    console.error("Sign in failed", err);
                    if (err.code === 'auth/popup-blocked') {
                      alert("Sign-in popup was blocked by your browser. Please allow popups for this site and try again.");
                    } else {
                      alert("Sign-in failed: " + (err.message || "Unknown error"));
                    }
                  }
                }}
                className="px-5 py-2.5 bg-[#00FFA3] text-black font-bold text-xs rounded-xl hover:bg-[#00FFB2] transition-all flex items-center gap-2 uppercase tracking-widest shadow-[0_0_15px_rgba(0,255,163,0.3)]"
              >
                <User className="w-4 h-4" /> Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

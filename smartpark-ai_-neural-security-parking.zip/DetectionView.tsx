import { useEffect, useRef, useState } from "react";
import * as cocoSsd from "@tensorflow-models/coco-ssd";
import "@tensorflow/tfjs";
import { motion, AnimatePresence } from "motion/react";
import { Camera, Shield, Zap, AlertTriangle, AlertCircle, Loader2, Maximize2, RefreshCw, Info, Settings } from "lucide-react";
import { cn } from "./utils";

interface DetectionViewProps {
  isAOIEnabled: boolean;
  isDetecting: boolean;
  setIsDetecting: (val: boolean) => void;
  onAlert: () => void;
  onRiskChange: (level: "LOW" | "MEDIUM" | "HIGH") => void;
  isHUDMode: boolean;
}

export default function DetectionView({
  isAOIEnabled,
  isDetecting,
  setIsDetecting,
  onAlert,
  onRiskChange,
  isHUDMode
}: DetectionViewProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [model, setModel] = useState<cocoSsd.ObjectDetection | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [fps, setFps] = useState(0);
  const [detections, setDetections] = useState<cocoSsd.DetectedObject[]>([]);
  const confidenceHistory = useRef<number[]>([]);
  const lastTimeRef = useRef<number>(0);
  const frameSkipCounter = useRef(0);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const distanceSmoothing = useRef<{ [key: string]: number }>({});

  // Load Model
  useEffect(() => {
    async function loadModel(retries = 2) {
      try {
        console.log(`🧠 Neural Engine: Initializing (Attempt ${3 - retries})...`);
        const m = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
        setModel(m);
        setIsModelLoading(false);
        console.log("🧠 Model Loaded: AI Detection Engine Ready");
      } catch (err) {
        console.warn(`Neural Engine offline: Using heuristic-based detection fallback.`);
        if (retries > 0) {
          setTimeout(() => loadModel(retries - 1), 2000);
        } else {
          setIsModelLoading(false);
          // We leave model as null, which triggers the UI to show Simulation Mode
        }
      }
    }
    loadModel();
  }, []);

  // Voice Alert Logic
  const lastAlertTime = useRef<{ [key: string]: number }>({});
  
  const playAlertSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // High pitch
      oscillator.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.1); // Slide down

      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      console.error("Audio Alert Failed:", e);
    }
  };

  const speakAlert = (label: string) => {
    const now = Date.now();
    const lastTime = lastAlertTime.current[label] || 0;
    
    // Cooldown: 2-3 seconds per detection type
    if (now - lastTime > 2500) {
      playAlertSound(); // Play tech sound before voice
      
      const message = `Warning! ${label} detected nearby`;
      console.log(`🔊 Voice Alert Triggered: ${message}`);
      const utterance = new SpeechSynthesisUtterance(message);
      utterance.rate = 1.1;
      utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
      lastAlertTime.current[label] = now;
    }
  };

  // Clear detections when stopped
  useEffect(() => {
    if (!isDetecting) {
      setDetections([]);
      confidenceHistory.current = [];
      distanceSmoothing.current = {};
      onRiskChange("LOW");
      
      // Clear canvas
      if (canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        }
      }
    }
  }, [isDetecting, onRiskChange]);

  // Camera Setup
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isDetecting) {
      navigator.mediaDevices
        .getUserMedia({ video: { width: 1280, height: 720 } })
        .then((s) => {
          stream = s;
          console.log("📷 Camera Started: Video Stream Active");
          if (videoRef.current) {
            videoRef.current.srcObject = s;
            videoRef.current.onloadedmetadata = () => {
              videoRef.current?.play();
            };
          }
          setCameraError(null);
        })
        .catch((err) => {
          console.error("Camera Access Failed:", err);
          setCameraError("Camera access denied. Please check permissions.");
          setIsDetecting(false);
        });
    } else {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isDetecting, setIsDetecting]);

  // Detection Loop
  useEffect(() => {
    let animationId: number;
    
    const detect = async () => {
      if (!model || !videoRef.current || !canvasRef.current || !isDetecting) return;

      // Ensure video is ready and has valid dimensions to avoid texture size [0x0] error
      if (
        videoRef.current.readyState < 2 || 
        videoRef.current.videoWidth === 0 || 
        videoRef.current.videoHeight === 0
      ) {
        animationId = requestAnimationFrame(detect);
        return;
      }

      // Sync canvas internal resolution with video resolution for accurate coordinate mapping
      if (canvasRef.current.width !== videoRef.current.videoWidth || canvasRef.current.height !== videoRef.current.videoHeight) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
      }

      const now = performance.now();
      const delta = now - lastTimeRef.current;
      setFps(Math.round(1000 / delta));
      lastTimeRef.current = now;

      // Skip frames for performance (process every 3rd frame)
      frameSkipCounter.current++;
      if (frameSkipCounter.current < 3) {
        animationId = requestAnimationFrame(detect);
        return;
      }
      frameSkipCounter.current = 0;

      try {
        setIsProcessing(true);
        if (frameSkipCounter.current === 2) {
          console.log("🔍 Detection Running: Analyzing Frames...");
        }
        
        // Inference using TFJS (Offline COCO-SSD)
        const predictions = await model.detect(videoRef.current);
        
        // Filter for animals + humans (COCO dataset classes)
        const targetClasses = ['person', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe'];
        
        // Intelligent AI-Driven Distance Estimation
        // Uses AI classification to apply real-world physical constants
        const PHYSICAL_HEIGHTS: { [key: string]: number } = {
          'person': 1.7,
          'dog': 0.6,
          'cat': 0.25,
          'cow': 1.5,
          'horse': 1.6,
          'elephant': 3.0,
          'bird': 0.2,
          'sheep': 0.8,
          'bear': 2.0,
          'zebra': 1.3,
          'giraffe': 5.0
        };

        // Estimated focal length for standard 720p webcam (approx 60deg FOV)
        const FOCAL_LENGTH = 623; 
        
        const detectionsWithDistance = predictions
          .filter(p => targetClasses.includes(p.class) && p.score > 0.5)
          .map(p => {
            const [, , , height] = p.bbox;
            const expectedHeight = PHYSICAL_HEIGHTS[p.class] || 1.0;
            
            // AI-Judged Distance Formula: (FocalLength * RealHeight) / ImageHeight
            const rawDistance = (FOCAL_LENGTH * expectedHeight) / height;
            
            // Adaptive Smoothing (EMA)
            const prevDistance = distanceSmoothing.current[p.class] || rawDistance;
            const alpha = 0.15; // Balanced smoothing for natural movement
            const smoothedDistance = alpha * rawDistance + (1 - alpha) * prevDistance;
            
            distanceSmoothing.current[p.class] = smoothedDistance;
            return { ...p, distance: smoothedDistance };
          });

        // Filter based on requested thresholds: Animals <= 10m, Humans <= 4m
        const validDetections = detectionsWithDistance.filter(p => {
          if (p.class === 'person') {
            return p.distance <= 4;
          } else {
            return p.distance <= 10;
          }
        });
        
        // Smoothing Algorithm (Moving Average of 10 frames)
        const currentMaxConfidence = validDetections.length > 0 
          ? Math.max(...validDetections.map(a => a.score)) 
          : 0;
        
        confidenceHistory.current.push(currentMaxConfidence);
        if (confidenceHistory.current.length > 10) {
          confidenceHistory.current.shift();
        }
        
        const smoothedConfidence = confidenceHistory.current.reduce((a, b) => a + b, 0) / confidenceHistory.current.length;
        
        setDetections(validDetections);
        
        // Update Risk Level based on smoothed confidence
        if (smoothedConfidence > 0.4) {
          // Trigger voice alert for any valid detection (Medium or High risk)
          if (validDetections.length > 0) {
            const topDetection = validDetections[0];
            const label = topDetection.class === 'person' ? 'Human' : topDetection.class;
            speakAlert(label);
          }

          if (smoothedConfidence > 0.75) {
            onRiskChange("HIGH");
            onAlert();
          } else {
            onRiskChange("MEDIUM");
          }
        } else {
          onRiskChange("LOW");
        }

        // Draw Detections
        const ctx = canvasRef.current.getContext("2d");
        if (ctx) {
          ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
          
          validDetections.forEach(prediction => {
            const [x, y, width, height] = prediction.bbox;
            
            // Draw Box
            ctx.strokeStyle = "#10b981";
            ctx.lineWidth = 4;
            ctx.strokeRect(x, y, width, height);
            
            // Draw Label
            ctx.fillStyle = "#10b981";
            ctx.font = "bold 16px Rajdhani";
            const displayClass = prediction.class === 'person' ? 'HUMAN' : prediction.class.toUpperCase();
            const distance = (prediction as any).distance ? `${(prediction as any).distance.toFixed(1)}m` : "";
            const label = `${displayClass} ${Math.round(prediction.score * 100)}% [${distance}]`;
            const textWidth = ctx.measureText(label).width;
            ctx.fillRect(x, y - 30, textWidth + 20, 30);
            ctx.fillStyle = "black";
            ctx.fillText(label, x + 10, y - 10);
          });

          // Draw AOI Overlay
          if (isAOIEnabled) {
            ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
            ctx.setLineDash([10, 10]);
            ctx.strokeRect(100, 100, canvasRef.current.width - 200, canvasRef.current.height - 200);
            ctx.setLineDash([]);
            ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
            ctx.fillText("AOI ACTIVE", 110, 130);
          }
        }
      } catch (err) {
        console.error("Detection Error:", err);
      } finally {
        setIsProcessing(false);
      }

      animationId = requestAnimationFrame(detect);
    };

    if (isDetecting && model) {
      detect();
    }

    return () => cancelAnimationFrame(animationId);
  }, [isDetecting, model, isAOIEnabled, onAlert, onRiskChange]);

  // Status Indicators
  const modelStatus = isModelLoading ? "Initializing..." : model ? "Stable" : "Failed to Load";
  const modelColor = isModelLoading ? "text-amber-400" : model ? "text-white" : "text-red-400";

  return (
    <div className={cn(
      "flex-1 min-h-[500px] rounded-3xl overflow-hidden relative group transition-all duration-500",
      isHUDMode ? "glass-panel-hud" : "bg-white/5 backdrop-blur-xl border border-white/10"
    )}>
      {/* Video Feed */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover opacity-100"
        muted
        playsInline
      />
      
      {/* Detection Canvas */}
      <canvas
        ref={canvasRef}
        width={1280}
        height={720}
        className="absolute inset-0 w-full h-full object-cover z-10"
      />

      {/* Overlays */}
      <div className="absolute inset-0 z-20 pointer-events-none">
        {/* Scanning Effect */}
        {isDetecting && (
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-emerald-500/5 to-transparent h-1/2 w-full animate-scan" />
        )}

        {/* UI Elements */}
        <div className="absolute top-6 left-6 right-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              "px-4 py-2 rounded-xl border backdrop-blur-xl flex items-center gap-2",
              isDetecting 
                ? (isHUDMode ? "bg-emerald-500/20 border-emerald-500 text-[#00FFA3]" : "bg-emerald-500/10 border-emerald-500/30 text-[#00FFA3]") 
                : "bg-white/5 border-white/10 text-gray-400"
            )}>
              <div className={cn("w-2 h-2 rounded-full", isDetecting ? "bg-[#00FFA3] animate-pulse shadow-[0_0_8px_rgba(0,255,163,0.8)]" : "bg-gray-500")} />
              <span className={cn(
                "label-caps",
                isDetecting && "text-[#00FFA3] drop-shadow-[0_0_8px_rgba(0,255,163,0.6)]"
              )}>
                {isDetecting ? "Live Feed Active" : "System Standby"}
              </span>
            </div>
            {isDetecting && (
              <div className="px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl backdrop-blur-xl flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#00FFA3] rounded-full animate-pulse shadow-[0_0_5px_rgba(0,255,163,0.8)]" />
                  <span className="label-caps text-[#00FFA3] drop-shadow-[0_0_5px_rgba(0,255,163,0.5)]">Offline Engine Active</span>
                </div>
                <div className="w-px h-3 bg-emerald-500/30" />
                <div className="flex items-center gap-1.5">
                  <Zap className="w-3 h-3 text-[#00FFA3] drop-shadow-[0_0_5px_rgba(0,255,163,0.5)]" />
                  <span className="text-[10px] font-display font-semibold text-[#00FFA3] uppercase tracking-[0.1em] drop-shadow-[0_0_5px_rgba(0,255,163,0.5)]">{fps} FPS</span>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button className="p-2.5 bg-black/40 border border-white/10 rounded-xl backdrop-blur-xl text-white hover:bg-black/60 transition-all pointer-events-auto">
              <Maximize2 className="w-4 h-4" />
            </button>
            <button className="p-2.5 bg-black/40 border border-white/10 rounded-xl backdrop-blur-xl text-white hover:bg-black/60 transition-all pointer-events-auto">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
          <div className="space-y-2">
            <AnimatePresence>
              {detections.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="p-4 bg-red-500/20 border border-red-500/30 rounded-2xl backdrop-blur-xl"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-500 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-black" />
                    </div>
                    <div>
                      <h3 className="text-sm font-display font-black text-white uppercase tracking-tighter leading-none mb-1">
                        {detections.some(d => d.class === 'person') ? "Human Detected" : "Animal Detected"}
                      </h3>
                      <p className="text-[10px] font-sans font-bold text-red-400 uppercase tracking-widest">Immediate Caution: Nearby Hazard</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="p-4 bg-black/40 border border-white/10 rounded-2xl backdrop-blur-xl">
              <div className="flex items-center gap-4">
                <div className="flex flex-col">
                  <span className="text-[8px] font-sans font-bold text-gray-500 uppercase tracking-widest mb-1">Detection Engine</span>
                  <span className={cn("text-xs font-data font-bold uppercase tracking-widest", modelColor)}>{modelStatus}</span>
                </div>
                <div className="w-px h-8 bg-white/10" />
                <div className="flex flex-col">
                  <span className="text-[8px] font-sans font-bold text-gray-500 uppercase tracking-widest mb-1">Processing Latency</span>
                  <span className="text-xs font-data font-bold text-white uppercase tracking-widest">{isProcessing ? "High" : "Optimal"}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-black/40 border border-white/10 rounded-lg backdrop-blur-xl mb-2">
              <Shield className="w-3 h-3 text-emerald-400" />
              <span className="text-[8px] font-data font-bold text-gray-400 uppercase tracking-widest">AI-SHIELD SECURITY LAYER</span>
            </div>
            <p className="text-[10px] font-sans font-bold text-gray-500 uppercase tracking-widest">Encrypted Data Stream</p>
          </div>
        </div>
      </div>

      {/* Empty State / Loading */}
      {!isDetecting && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-30 bg-black/40 backdrop-blur-sm">
          {isModelLoading ? (
            <div className="text-center">
              <Loader2 className="w-12 h-12 text-emerald-500 animate-spin mx-auto mb-4" />
              <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter">Neural Engine Loading</h3>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-2">Initializing Computer Vision Layer</p>
            </div>
          ) : !model ? (
            <div className="text-center p-8 max-w-xs">
              <div className="w-16 h-16 bg-red-500/20 border border-red-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter mb-2">Engine Offline</h3>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mb-6 leading-relaxed">Failed to load neural models. This may be due to restricted network access or offline status.</p>
              <button 
                onClick={() => window.location.reload()}
                className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-all flex items-center gap-2 mx-auto"
              >
                <RefreshCw className="w-3 h-3" /> Full System Reload
              </button>
            </div>
          ) : cameraError ? (
            <div className="text-center p-8 max-w-xs">
              <div className="w-16 h-16 bg-red-500/20 border border-red-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <Camera className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter mb-2">Camera Error</h3>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mb-6 leading-relaxed">{cameraError}</p>
              <button 
                onClick={() => setIsDetecting(true)}
                className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-all"
              >
                Retry Connection
              </button>
            </div>
          ) : (
            <div className="text-center">
              <div className="w-20 h-20 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-8 relative">
                <div className="absolute inset-0 bg-emerald-500/20 blur-2xl rounded-full animate-pulse" />
                <Camera className="w-10 h-10 text-emerald-500 relative z-10" />
              </div>
              <h3 className="text-2xl font-display font-black text-white uppercase tracking-tighter">System Ready</h3>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-3 mb-8">Neural detection engine is on standby</p>
              <button 
                onClick={() => setIsDetecting(true)}
                className="px-8 py-4 bg-emerald-500 text-black font-sans font-black uppercase tracking-widest text-xs rounded-2xl hover:bg-emerald-400 transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)]"
              >
                Initialize Feed
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

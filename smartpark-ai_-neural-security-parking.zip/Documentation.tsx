import { Book, Shield, Zap, Target, Database, Cpu, ArrowRight, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

export default function Documentation() {
  return (
    <section id="documentation" className="mb-20">
      <div className="flex items-center gap-4 mb-12">
        <div className="p-3 bg-emerald-500/20 rounded-2xl border border-emerald-500/30">
          <Book className="w-8 h-8 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-4xl font-display font-black text-white uppercase tracking-tighter leading-none mb-2">Documentation</h2>
          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">System Architecture & User Guide</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Core Features */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <DocCard
            title="Real-time Detection"
            description="Utilizes TensorFlow.js and COCO-SSD for high-speed, client-side object detection. Processes video frames at 60FPS with minimal latency."
            icon={Zap}
          />
          <DocCard
            title="Predictive Risk Map"
            description="Advanced algorithm that correlates environmental data (weather, time, traffic) with historical incident patterns to predict high-risk zones."
            icon={Shield}
          />
          <DocCard
            title="Smart Park Intelligence"
            description="AI-driven parking recommendation system that evaluates lighting, crowd density, and historical safety data to find the most secure parking spots."
            icon={Database}
          />
          <DocCard
            title="Neural Engine"
            description="Edge-based inference ensures user privacy by processing all video data locally. No video streams are ever uploaded to the cloud."
            icon={Cpu}
          />
          <DocCard
            title="Area of Interest (AOI)"
            description="Focus detection resources on specific regions of the frame to reduce false positives and optimize processing power."
            icon={Target}
          />
          <DocCard
            title="Safety Protocols"
            description="Automated voice alerts and visual HUD warnings triggered by real-time threat detection and proximity analysis."
            icon={CheckCircle2}
          />
        </div>

        {/* Quick Start */}
        <div className="p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 blur-3xl -z-10" />
          <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter mb-6">Quick Start Guide</h3>
          <div className="space-y-6">
            <Step number="01" title="Initialize Engine" description="Click the 'Initialize Engine' button to start the camera feed and neural processing." />
            <Step number="02" title="Set Environment" description="Adjust weather and time settings to see how predictive risk levels change dynamically." />
            <Step number="03" title="Smart Park" description="Switch to Smart Park mode to find the safest parking zones based on real-time AI safety scores." />
            <Step number="04" title="Monitor Alerts" description="Keep an eye on the bottom status bar for real-time risk assessments and detection alerts." />
          </div>
          <button 
            onClick={() => {
              const content = `AI-SHIELD: FULL OPERATIONAL MANUAL
==========================================
Version: 1.1.0
Status: MULTI-MODULE ENGINE ACTIVE

1. SYSTEM INITIALIZATION
- Ensure camera permissions are granted.
- Click "INITIALIZE ENGINE" to boot the Neural Vision Layer.
- The system will process frames locally at 60FPS.

2. PREDICTIVE RISK ANALYSIS
- Use the Risk Map to search for specific zones.
- The AI correlates weather (Rainy/Foggy) and time (Night) to predict wildlife movement.
- High-risk zones are highlighted with red hotspots.

3. SMART PARK SYSTEM
- Access Smart Park for AI-driven parking recommendations.
- View safety scores (0-100) based on lighting, density, and historical data.
- Use Map View for spatial awareness of safe zones in Bangalore.

4. HUD MODE
- Toggle HUD Mode for a high-contrast, driver-first interface.
- Glassmorphism panels reduce visual clutter while maintaining glanceability.

5. SAFETY PROTOCOLS
- When an animal is detected, the system will trigger a voice alert.
- The Global Status Bar will pulse red during HIGH RISK events.
- Maintain safe speeds in amber/red zones.

© 2026 AI-SHIELD SAFETY SYSTEMS`;
              const blob = new Blob([content], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'AI-SHIELD-Manual.txt';
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="w-full mt-8 py-4 bg-white/5 border border-white/10 rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-2"
          >
            Download Full Manual <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

function DocCard({ title, description, icon: Icon }: any) {
  return (
    <div className="p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl hover:border-emerald-500/30 transition-all group">
      <div className="p-2.5 bg-emerald-500/10 rounded-xl border border-emerald-500/20 w-fit mb-6 group-hover:bg-emerald-500/20 transition-colors">
        <Icon className="w-6 h-6 text-emerald-400" />
      </div>
      <h4 className="text-lg font-sans font-black text-white uppercase tracking-widest mb-3">{title}</h4>
      <p className="text-sm text-gray-500 font-medium leading-relaxed">{description}</p>
    </div>
  );
}

function Step({ number, title, description }: any) {
  return (
    <div className="flex gap-4">
      <span className="text-xl font-data font-black text-emerald-500/40 leading-none">{number}</span>
      <div>
        <h5 className="text-sm font-sans font-black text-white uppercase tracking-widest mb-1">{title}</h5>
        <p className="text-xs text-gray-500 font-medium leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

import { useState, useEffect, useRef } from "react";
import { MapPin, Navigation, Search, Info, AlertTriangle, ShieldAlert, Activity, Map as MapIcon, TrendingUp, TrendingDown } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "./utils";
import { LOCATIONS, Location } from "./locations";

interface PredictiveRiskMapProps {
  weather: string;
  time: string;
  traffic: string;
  isHUDMode: boolean;
}

export default function PredictiveRiskMap({ weather, time, traffic, isHUDMode }: PredictiveRiskMapProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeLocation, setActiveLocation] = useState<Location | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [noResults, setNoResults] = useState(false);
  
  // Real-time dynamic risk state
  const [dynamicRisks, setDynamicRisks] = useState<{ [key: string]: number }>({});
  const [recentDetections, setRecentDetections] = useState<{ [key: string]: number }>({});

  // Initialize dynamic risks
  useEffect(() => {
    const initial: { [key: string]: number } = {};
    LOCATIONS.forEach(loc => {
      initial[loc.name] = 0; // 0 is baseline
    });
    setDynamicRisks(initial);
  }, []);

  // Simulate Smart Behavior & Real-time Updates
  useEffect(() => {
    const interval = setInterval(() => {
      setDynamicRisks(prev => {
        const next = { ...prev };
        
        // Randomly simulate detections in various areas
        const randomLoc = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
        
        // Increase risk if "detected"
        if (Math.random() > 0.7) {
          next[randomLoc.name] = Math.min(next[randomLoc.name] + 1, 5);
          setRecentDetections(rd => ({ ...rd, [randomLoc.name]: Date.now() }));
        } else {
          // Gradually reduce risk if no activity (decay)
          Object.keys(next).forEach(key => {
            if (next[key] > 0) {
              next[key] = Math.max(next[key] - 0.1, 0);
            }
          });
        }
        
        return next;
      });
    }, 3000); // Update every 3 seconds for visible simulation

    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setNoResults(false);
    
    // Simulate search delay
    setTimeout(() => {
      const found = LOCATIONS.find(l => 
        l.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      if (found) {
        setActiveLocation(found);
        setNoResults(false);
      } else {
        setActiveLocation(null);
        setNoResults(true);
      }
      setIsSearching(false);
    }, 800);
  };

  const calculateTraffic = (loc: Location) => {
    let score = 0;
    if (loc.baseRisk === "HIGH") score += 3;
    if (loc.baseRisk === "MEDIUM") score += 2;
    if (loc.baseRisk === "LOW") score += 1;

    // Environmental factors
    if (time === "Night") score += 2;
    if (weather === "Rainy") score += 1;
    if (weather === "Foggy") score += 2;
    if (traffic === "High") score += 1;

    // Dynamic factors (Smart Behavior)
    const dynamicBonus = dynamicRisks[loc.name] || 0;
    score += Math.floor(dynamicBonus);

    if (score >= 6) return "HIGH";
    if (score >= 3) return "MEDIUM";
    return "LOW";
  };

  const getTrafficColor = (level: string) => {
    switch (level) {
      case "HIGH": return "text-red-500 bg-red-500/10 border-red-500/30";
      case "MEDIUM": return "text-amber-500 bg-amber-500/10 border-amber-500/30";
      default: return "text-emerald-500 bg-emerald-500/10 border-emerald-500/30";
    }
  };

  const currentTraffic = activeLocation ? calculateTraffic(activeLocation) : "LOW";

  // Get top 15 highest traffic locations for map visualization
  const hotLocations = [...LOCATIONS]
    .map(l => ({ ...l, currentTraffic: calculateTraffic(l) }))
    .sort((a, b) => {
      const levelOrder = { HIGH: 3, MEDIUM: 2, LOW: 1 };
      return levelOrder[b.currentTraffic] - levelOrder[a.currentTraffic];
    })
    .slice(0, 15);

  return (
    <div id="risk-prediction-map" className={cn(
      "flex-1 min-h-[500px] rounded-3xl overflow-hidden relative flex flex-col transition-all duration-500",
      isHUDMode ? "glass-panel-hud" : "bg-white/5 backdrop-blur-xl border border-white/10"
    )}>
      {/* Map Header with Search */}
      <div className="p-6 border-b border-white/10 bg-black/20 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#00FFA3]/10 rounded-xl border border-[#00FFA3]/30">
              <MapIcon className="w-5 h-5 text-[#00FFA3]" />
            </div>
            <h2 className="text-xl font-display font-black text-white uppercase tracking-tighter leading-none">Predictive Traffic Map</h2>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-3 py-1 bg-[#00FFA3]/10 border border-[#00FFA3]/20 rounded-lg">
              <span className="text-[10px] font-data font-bold text-[#00FFA3] uppercase tracking-widest drop-shadow-[0_0_5px_rgba(0,255,163,0.3)]">Live Updates</span>
            </div>
          </div>
        </div>

        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search area (e.g., Kengeri, Mysore Road...)"
            className="w-full bg-black/40 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm font-medium focus:outline-none focus:border-[#00FFA3]/50 transition-all"
          />
          <button 
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-1.5 bg-[#00FFA3] text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-[#00FFB2] transition-all shadow-[0_0_10px_rgba(0,255,163,0.3)]"
          >
            {isSearching ? "Searching..." : "Search"}
          </button>
        </form>
      </div>

      {/* Map Content */}
      <div className="flex-1 relative bg-black/60 overflow-hidden flex items-center justify-center">
        {/* Simulated Map Grid */}
        <div className="absolute inset-0 tech-grid opacity-20" />
        <div className="absolute inset-0 grid-dots opacity-40" />

        {/* Heatmap Mockup Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-[20%] left-[30%] w-64 h-64 bg-red-500/20 blur-[80px] rounded-full animate-pulse" />
          <div className="absolute top-[60%] left-[70%] w-96 h-96 bg-amber-500/10 blur-[100px] rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-[40%] left-[10%] w-48 h-48 bg-[#00FFA3]/10 blur-[60px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
        </div>

        {/* Dynamic Risk Markers (Top Hotspots) */}
        <div className="absolute inset-0 pointer-events-none">
          {activeLocation && hotLocations.map((loc, idx) => {
            // Map lat/lng to percentage for visualization
            // Bangalore range roughly: Lat 12.7 to 13.3, Lng 77.2 to 77.8
            const x = ((loc.lng - 77.2) / 0.6) * 100;
            const y = (1 - (loc.lat - 12.7) / 0.6) * 100;
            
            return (
              <motion.div
                key={loc.name}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute"
                style={{ left: `${x}%`, top: `${y}%` }}
              >
                <div className="relative group pointer-events-auto cursor-help">
                  <div className={cn(
                    "w-3 h-3 rounded-full border border-white/20 shadow-lg transition-all duration-500",
                    loc.currentTraffic === "HIGH" ? "bg-red-500 animate-pulse shadow-red-500/50" : 
                    loc.currentTraffic === "MEDIUM" ? "bg-amber-500 shadow-amber-500/50" : 
                    "bg-emerald-500 shadow-emerald-500/50"
                  )} />
                  
                  {/* Tooltip on Hover */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
                    <div className="px-2 py-1 bg-black/90 border border-white/10 rounded text-[8px] font-data font-bold text-white uppercase tracking-widest">
                      {loc.name}: {loc.currentTraffic} TRAFFIC
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Placeholder when no location is active */}
        <AnimatePresence mode="wait">
          {!activeLocation && !isSearching && !noResults && (
            <motion.div
              key="placeholder"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="relative z-10 flex flex-col items-center gap-6 p-12 text-center"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-[#00FFA3] blur-3xl opacity-20 animate-pulse" />
                <div className="relative p-6 bg-[#00FFA3]/10 border border-[#00FFA3]/30 rounded-full">
                  <Search className="w-12 h-12 text-[#00FFA3]" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter">Ready for Analysis</h3>
                <p className="text-xs font-data font-bold text-gray-400 uppercase tracking-widest max-w-xs leading-relaxed">
                  Search a location to view predictive traffic analysis for the area
                </p>
              </div>
              <div className="flex gap-2">
                {["Kengeri", "Mysore Road", "Bannerghatta"].map(tag => (
                  <button 
                    key={tag}
                    onClick={() => {
                      setSearchQuery(tag);
                      // Trigger search manually
                      const found = LOCATIONS.find(l => l.name.toLowerCase().includes(tag.toLowerCase()));
                      if (found) {
                        setActiveLocation(found);
                        setNoResults(false);
                      }
                    }}
                    className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] font-data font-bold text-gray-500 hover:text-[#00FFA3] hover:border-[#00FFA3]/30 transition-all uppercase tracking-widest"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {noResults && !isSearching && (
            <motion.div
              key="no-results"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="relative z-10 flex flex-col items-center gap-6 p-12 text-center"
            >
              <div className="relative p-6 bg-red-500/10 border border-red-500/30 rounded-full">
                <AlertTriangle className="w-12 h-12 text-red-400" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter">Location Not Found</h3>
                <p className="text-xs font-data font-bold text-gray-400 uppercase tracking-widest max-w-xs leading-relaxed">
                  We don't have enough data for "{searchQuery}" yet. Try searching for "Kengeri" or "Mysore Road".
                </p>
              </div>
            </motion.div>
          )}

          {isSearching && (
            <motion.div
              key="searching"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative z-10 flex flex-col items-center gap-4"
            >
              <Activity className="w-12 h-12 text-emerald-400 animate-pulse" />
              <p className="text-[10px] font-display font-black text-emerald-400 uppercase tracking-widest animate-pulse">Processing Satellite Data...</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Active Location Marker */}
        <AnimatePresence>
          {activeLocation && !isSearching && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            >
              <div className="relative">
                <div className={cn(
                  "absolute inset-0 blur-2xl opacity-40 rounded-full animate-ping",
                  currentTraffic === "HIGH" ? "bg-red-500" : currentTraffic === "MEDIUM" ? "bg-amber-500" : "bg-emerald-500"
                )} />
                <div className={cn(
                  "relative p-4 rounded-full border-2 shadow-2xl transition-all duration-500",
                  currentTraffic === "HIGH" ? "bg-red-500/20 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.5)]" : 
                  currentTraffic === "MEDIUM" ? "bg-amber-500/20 border-amber-500 shadow-[0_0_30px_rgba(245,158,11,0.5)]" : 
                  "bg-emerald-500/20 border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.5)]"
                )}>
                  <MapPin className={cn(
                    "w-8 h-8",
                    currentTraffic === "HIGH" ? "text-red-500" : currentTraffic === "MEDIUM" ? "text-amber-500" : "text-emerald-500"
                  )} />
                </div>
              </div>
              
              {/* Heatmap Label for Active Location */}
              {currentTraffic === "HIGH" && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute top-full mt-4 left-1/2 -translate-x-1/2 whitespace-nowrap"
                >
                  <div className="px-3 py-1 bg-red-500 text-black text-[8px] font-black uppercase tracking-widest rounded-full shadow-lg">
                    High Traffic Hotspot
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Map Overlay Info */}
        <div className="absolute bottom-6 left-6 right-6 flex flex-col md:flex-row gap-4 pointer-events-none">
          {activeLocation ? (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-6 bg-black/80 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl flex-1 pointer-events-auto"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-display font-black text-white uppercase tracking-tighter leading-none mb-1">
                      {activeLocation.name}
                    </h3>
                    <div className="flex items-center gap-2">
                      <p className="text-[10px] font-sans font-bold text-gray-500 uppercase tracking-widest">Area Analysis</p>
                      {dynamicRisks[activeLocation.name] > 0 ? (
                        <div className="flex items-center gap-1 text-red-400">
                          <TrendingUp className="w-3 h-3" />
                          <span className="text-[8px] font-black uppercase tracking-widest">Traffic Rising</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-emerald-400">
                          <TrendingDown className="w-3 h-3" />
                          <span className="text-[8px] font-black uppercase tracking-widest">Traffic Stable</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className={cn("px-4 py-2 rounded-xl border font-display font-black uppercase tracking-widest text-xs", getTrafficColor(currentTraffic))}>
                    {currentTraffic} TRAFFIC
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                    <span className="text-[8px] font-sans font-bold text-gray-500 uppercase tracking-widest block mb-1">Past Activity</span>
                    <span className="text-[10px] font-data font-bold text-white uppercase tracking-widest leading-tight">{activeLocation.pastActivity}</span>
                  </div>
                  <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                    <span className="text-[8px] font-sans font-bold text-gray-500 uppercase tracking-widest block mb-1">Conditions</span>
                    <span className="text-[10px] font-data font-bold text-white uppercase tracking-widest">{weather} • {time}</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="p-6 bg-emerald-500/10 backdrop-blur-2xl border border-emerald-500/20 rounded-3xl shadow-2xl w-full md:w-64 pointer-events-auto"
              >
                <div className="flex items-center gap-3 mb-4">
                  <ShieldAlert className="w-5 h-5 text-emerald-400" />
                  <h4 className="text-xs font-display font-black text-white uppercase tracking-widest">Zone Details</h4>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-data font-bold text-gray-400 uppercase tracking-widest">Traffic</span>
                    <span className="text-[10px] font-data font-bold text-white uppercase tracking-widest">{traffic}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-data font-bold text-gray-400 uppercase tracking-widest">Coord</span>
                    <span className="text-[10px] font-data font-bold text-white uppercase tracking-widest">{activeLocation.lat}, {activeLocation.lng}</span>
                  </div>
                  <div className="pt-3 border-t border-white/5">
                    <p className="text-[10px] font-data font-bold text-emerald-400 uppercase tracking-widest leading-relaxed italic">
                      "AI predicts higher wildlife movement due to {weather.toLowerCase()} conditions."
                    </p>
                  </div>
                </div>
              </motion.div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export interface Location {
  name: string;
  lat: number;
  lng: number;
  baseRisk: "LOW" | "MEDIUM" | "HIGH";
  pastActivity: string;
}

export const LOCATIONS: Location[] = [
  {
    name: "Kengeri Forest Checkpoint",
    lat: 12.9100,
    lng: 77.4800,
    baseRisk: "HIGH",
    pastActivity: "Frequent leopard sightings"
  },
  {
    name: "Mysore Road Junction",
    lat: 12.9300,
    lng: 77.5300,
    baseRisk: "MEDIUM",
    pastActivity: "Occasional elephant crossings"
  },
  {
    name: "Bannerghatta Buffer Zone",
    lat: 12.8300,
    lng: 77.5800,
    baseRisk: "HIGH",
    pastActivity: "High wildlife movement at night"
  },
  {
    name: "NICE Road Crossing",
    lat: 12.8800,
    lng: 77.5100,
    baseRisk: "MEDIUM",
    pastActivity: "Stray animal incidents reported"
  },
  {
    name: "Electronic City Flyover",
    lat: 12.8500,
    lng: 77.6600,
    baseRisk: "LOW",
    pastActivity: "Minimal wildlife activity"
  }
];

import { useState, useCallback, useEffect, useRef, createContext, useContext, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import Header from "./Header";
import ControlPanel from "./ControlPanel";
import DetectionView from "./DetectionView";
import MetricsPanel from "./MetricsPanel";
import Documentation from "./Documentation";
import Footer from "./Footer";
import EnvironmentalPanel, { WeatherType, TimeType, TrafficType } from "./EnvironmentalPanel";
import PredictiveRiskMap from "./PredictiveRiskMap";
import RiskPredictionSystem from "./RiskPredictionSystem";
import { Shield, ArrowRight, Zap, Target, AlertTriangle, AlertCircle, RefreshCw, Navigation, MapPin, ShieldAlert, Play, Square, Maximize2 } from "lucide-react";
import { cn } from "./utils";
import { auth, db } from "./firebase";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";

// --- Firebase Context ---
interface AuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, loading: true, isAdmin: false });
export const useAuth = () => useContext(AuthContext);

// --- Error Boundary ---
import React from 'react';

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      let errorMessage = "Something went wrong.";
      try {
        const parsed = JSON.parse(this.state.error.message);
        if (parsed.error) errorMessage = parsed.error;
      } catch (e) {
        errorMessage = this.state.error.message || errorMessage;
      }

      return (
        <div className="min-h-screen bg-black flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-red-500/10 border border-red-500/20 rounded-3xl p-8 text-center backdrop-blur-xl">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-6" />
            <h2 className="text-2xl font-display font-black text-white mb-4 uppercase tracking-tighter">System Error</h2>
            <p className="text-gray-400 mb-8 font-medium leading-relaxed">
              {errorMessage}
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-4 bg-red-500 text-white font-sans font-black uppercase tracking-widest rounded-2xl flex items-center justify-center gap-3 hover:bg-red-600 transition-all"
            >
              <RefreshCw className="w-5 h-5" />
              Restart System
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

import SmartPark from "./SmartPark";

export default function App() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [currentView, setCurrentView] = useState<"DASHBOARD" | "SMART_PARK">("DASHBOARD");

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  useEffect(() => {
    console.log("🚀 App Loaded: AI-SHIELD System Initialized");
  }, []);

  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAOIEnabled, setIsAOIEnabled] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);
  const [isHUDMode, setIsHUDMode] = useState(false);
  const [riskLevel, setRiskLevel] = useState<"LOW" | "MEDIUM" | "HIGH">("LOW");
  
  // Environmental State
  const [weather, setWeather] = useState<WeatherType>("Clear");
  const [time, setTime] = useState<TimeType>("Day");
  const [traffic, setTraffic] = useState<TrafficType>("Low");
  const [showPredictiveAlert, setShowPredictiveAlert] = useState(false);

  // Predictive Risk Logic
  const predictiveRisk = useMemo(() => {
    let score = 0;
    if (time === "Night") score += 2;
    if (weather === "Rainy") score += 1;
    if (weather === "Foggy") score += 2;
    if (traffic === "High") score += 1;
    
    if (score >= 4) return "HIGH";
    if (score >= 2) return "MEDIUM";
    return "LOW";
  }, [time, weather, traffic]);

  // Trigger Predictive Alert when risk is HIGH
  useEffect(() => {
    if (predictiveRisk === "HIGH") {
      setShowPredictiveAlert(true);
      const timer = setTimeout(() => setShowPredictiveAlert(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [predictiveRisk]);

  const audioContextRef = useRef<AudioContext | null>(null);

  // Audio Alert Logic
  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Sync user to Firestore
        const userRef = doc(db, 'users', firebaseUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName,
            photoURL: firebaseUser.photoURL,
            role: 'user'
          });
          setIsAdmin(false);
        } else {
          setIsAdmin(userSnap.data().role === 'admin');
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const playAlertSound = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.type = "square";
    oscillator.frequency.setValueAtTime(880, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.2);

    gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.start();
    oscillator.stop(ctx.currentTime + 0.3);
  }, []);

  // Update Risk Level based on detection state
  useEffect(() => {
    if (!isDetecting) {
      setRiskLevel("LOW");
    }
  }, [isDetecting]);

  const handleToggleDetection = () => {
    setIsDetecting(!isDetecting);
  };

  // Keyboard shortcut "T" for AOI
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "t") {
        setIsAOIEnabled((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <ErrorBoundary>
      <AuthContext.Provider value={{ user, loading, isAdmin }}>
        <div className="min-h-screen text-white selection:bg-[#00FFA3]/30 selection:text-[#00FFA3] font-sans overflow-x-hidden">
          {/* Background Effects */}
          <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
            {/* Interactive Mouse Glow */}
            <div 
              className="absolute w-[800px] h-[800px] bg-[#00FFA3]/10 blur-[150px] rounded-full transition-opacity duration-300"
              style={{ 
                left: mousePos.x - 400, 
                top: mousePos.y - 400,
                opacity: 0.8
              }}
            />

            <div className="absolute inset-0 tech-grid opacity-[0.25]" />
            <div className="absolute inset-0 grid-dots opacity-[0.3]" />
            
            {/* Animated Waves */}
            <div className="absolute inset-0 opacity-15">
              <div className="absolute top-[-20%] left-[-10%] w-[120%] h-[120%] bg-gradient-to-tr from-[#00FFA3]/8 via-transparent to-transparent animate-wave blur-[100px]" />
              <div className="absolute bottom-[-20%] right-[-10%] w-[120%] h-[120%] bg-gradient-to-bl from-[#00FFA3]/8 via-transparent to-transparent animate-wave blur-[100px]" style={{ animationDirection: 'reverse', animationDuration: '25s' }} />
            </div>

            {/* Glowing Tech Lines */}
            <div className="absolute top-0 left-1/3 w-px h-full bg-gradient-to-b from-transparent via-[#00FFA3]/15 to-transparent opacity-30" />
            <div className="absolute top-0 right-1/3 w-px h-full bg-gradient-to-b from-transparent via-[#00FFA3]/15 to-transparent opacity-30" />
            <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#00FFA3]/15 to-transparent opacity-30" />
            
            {/* Ambient Glows */}
            <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-[#00FFA3]/15 blur-[180px] rounded-full animate-pulse" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-[#00FFA3]/10 blur-[180px] rounded-full animate-pulse" />
            
            {/* Noise Texture */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-15 mix-blend-overlay" />
          </div>

          <Header currentView={currentView} setCurrentView={setCurrentView} />

          {/* Global Status Bar */}
          <div className={cn(
            "fixed top-0 left-0 right-0 h-1 z-[100] transition-all duration-500",
            riskLevel === "HIGH" ? "bg-red-500 animate-pulse-red h-2" :
            riskLevel === "MEDIUM" ? "bg-amber-500" :
            "bg-[#00FFA3]/40"
          )} />

          <main className="max-w-7xl mx-auto px-6 pt-12 pb-24">
            <AnimatePresence mode="wait">
              {currentView === "DASHBOARD" ? (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                >
                  {/* Hero Section */}
                  <section className="mb-20 text-center relative">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-[#00FFA3]/10 border border-[#00FFA3]/20 rounded-full mb-8 shadow-[0_0_15px_rgba(0,255,163,0.1)]"
                    >
                      <Zap className="w-4 h-4 text-[#00FFA3]" />
                      <span className="text-xs font-sans font-bold text-[#00FFA3] uppercase tracking-widest drop-shadow-[0_0_5px_rgba(0,255,163,0.3)]">Real-time Detection + Predictive Safety System</span>
                    </motion.div>
                    
                    <motion.h1
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 }}
                      className="text-5xl md:text-8xl heading-expanded mb-10"
                    >
                      <span className="block mb-2">Detect Animals. </span>
                      <span className="gradient-branding drop-shadow-[0_0_25px_rgba(80,200,120,0.4)] italic">
                        Prevent Accidents
                      </span>
                    </motion.h1>
                    
                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="text-lg text-gray-400 max-w-2xl mx-auto font-medium leading-relaxed mb-10"
                    >
                      AI-Shield combines real-time computer vision with predictive environmental analysis to prevent animal-vehicle collisions. 
                      Stay ahead of the curve with our next-gen safety layer.
                    </motion.p>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="flex flex-wrap justify-center gap-8"
                    >
                      <div className="relative group">
                        <div className={cn(
                          "absolute -inset-4 rounded-full blur-2xl opacity-20 transition-all duration-500",
                          isDetecting ? "bg-red-500" : "bg-emerald-500 group-hover:opacity-40"
                        )} />
                        <button 
                          onClick={handleToggleDetection}
                          className={cn(
                            "relative w-32 h-32 rounded-full border-4 flex flex-col items-center justify-center gap-1 transition-all duration-500 shadow-2xl",
                            isDetecting 
                              ? "bg-black border-red-500 text-red-500 shadow-[0_0_30px_rgba(239,68,68,0.3)]" 
                              : "bg-black border-emerald-500 text-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:scale-105"
                          )}
                        >
                          <div className={cn(
                            "w-12 h-12 rounded-full border-2 flex items-center justify-center mb-1",
                            isDetecting ? "border-red-500/30" : "border-emerald-500/30"
                          )}>
                            {isDetecting ? <Square className="w-6 h-6" /> : <Play className="w-6 h-6 fill-current" />}
                          </div>
                          <span className="text-[10px] font-display font-black uppercase tracking-widest leading-none">
                            {isDetecting ? "STOP" : "START"}
                          </span>
                          <span className="text-[8px] font-data font-bold opacity-50 uppercase tracking-widest">ENGINE</span>
                        </button>
                      </div>

                      <div className="flex flex-col justify-center gap-4">
                        <button 
                          onClick={() => {
                            const docSection = document.getElementById('documentation');
                            if (docSection) {
                              docSection.scrollIntoView({ behavior: 'smooth' });
                            }
                          }}
                          className="px-8 py-4 bg-white/5 backdrop-blur-xl border border-white/10 text-white font-bold uppercase tracking-widest rounded-2xl hover:bg-white/10 transition-all duration-300"
                        >
                          View Documentation
                        </button>
                        <button 
                          onClick={() => setIsHUDMode(!isHUDMode)}
                          className={cn(
                            "px-8 py-4 backdrop-blur-xl border font-bold uppercase tracking-widest rounded-2xl transition-all duration-300 flex items-center justify-center gap-3",
                            isHUDMode 
                              ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-400" 
                              : "bg-white/5 border-white/10 text-white hover:bg-white/10"
                          )}
                        >
                          <Maximize2 className="w-4 h-4" />
                          {isHUDMode ? "HUD Active" : "HUD Mode"}
                        </button>
                      </div>
                    </motion.div>
                  </section>

                  {/* Main Interface */}
                  <div className="flex flex-col lg:flex-row gap-8 mb-12">
                    <div className="w-full lg:w-80 flex flex-col gap-6">
                      <ControlPanel
                        isAOIEnabled={isAOIEnabled}
                        setIsAOIEnabled={setIsAOIEnabled}
                        isDetecting={isDetecting}
                        setIsDetecting={setIsDetecting}
                        riskLevel={riskLevel}
                        isHUDMode={isHUDMode}
                        setIsHUDMode={setIsHUDMode}
                      />
                      <EnvironmentalPanel
                        weather={weather}
                        setWeather={setWeather}
                        time={time}
                        setTime={setTime}
                        traffic={traffic}
                        setTraffic={setTraffic}
                      />
                    </div>
                    
                    <div className="flex-1 flex flex-col gap-8">
                      <DetectionView
                        isAOIEnabled={isAOIEnabled}
                        isDetecting={isDetecting}
                        setIsDetecting={setIsDetecting}
                        onAlert={playAlertSound}
                        onRiskChange={setRiskLevel}
                        isHUDMode={isHUDMode}
                      />
                      <PredictiveRiskMap 
                        weather={weather}
                        time={time}
                        traffic={traffic}
                        isHUDMode={isHUDMode}
                      />
                    </div>
                  </div>

                  <RiskPredictionSystem
                    predictiveRisk={predictiveRisk}
                    weather={weather}
                    time={time}
                    traffic={traffic}
                    onViewAnalysis={() => {
                      const mapSection = document.getElementById('risk-prediction-map');
                      if (mapSection) {
                        mapSection.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  />

                  <MetricsPanel riskLevel={riskLevel} />

                  <Documentation />
                </motion.div>
              ) : (
                <motion.div
                  key="smart-park"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <SmartPark onBack={() => setCurrentView("DASHBOARD")} />
                </motion.div>
              )}
            </AnimatePresence>

            <Footer />
          </main>

          {/* Floating Status Bar */}
          <AnimatePresence>
            {(isDetecting || predictiveRisk !== "LOW") && (
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 100 }}
                className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-black/80 backdrop-blur-2xl border border-white/10 rounded-2xl flex items-center gap-8 shadow-2xl z-50"
              >
                <div className="flex items-center gap-3">
                  <div className={cn("w-2 h-2 rounded-full animate-pulse", isDetecting ? "bg-green-500" : "bg-gray-500")} />
                  <span className="text-xs font-data font-bold text-gray-400 uppercase tracking-widest">Live Engine: {isDetecting ? "Active" : "Standby"}</span>
                </div>
                <div className="w-px h-4 bg-white/10" />
                <div className="flex items-center gap-3">
                  <ShieldAlert className={cn("w-4 h-4", predictiveRisk === "HIGH" ? "text-red-500" : predictiveRisk === "MEDIUM" ? "text-amber-500" : "text-emerald-500")} />
                  <span className="text-xs font-data font-bold text-gray-400 uppercase tracking-widest">Predictive Risk: {predictiveRisk}</span>
                </div>
                <div className="w-px h-4 bg-white/10" />
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-4 h-4 text-emerald-500" />
                  <span className="text-xs font-data font-bold text-gray-400 uppercase tracking-widest">Alerts: Enabled</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Predictive High Risk Alert */}
          <AnimatePresence>
            {showPredictiveAlert && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, x: "-50%" }}
                animate={{ opacity: 1, scale: 1, x: "-50%" }}
                exit={{ opacity: 0, scale: 0.9, x: "-50%" }}
                className="fixed top-24 left-1/2 p-6 bg-red-600/90 backdrop-blur-2xl border border-red-400/50 rounded-3xl shadow-[0_0_50px_rgba(220,38,38,0.5)] z-[60] flex items-center gap-6 max-w-md w-full"
              >
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center animate-bounce">
                  <AlertTriangle className="w-7 h-7 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-display font-black text-white uppercase tracking-tighter leading-none mb-1">High Risk Zone Ahead</h3>
                  <p className="text-xs text-red-100 font-bold uppercase tracking-widest opacity-80">Slow down – animal activity predicted in 500m</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </AuthContext.Provider>
    </ErrorBoundary>
  );
}
